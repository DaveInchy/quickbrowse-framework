<li class="nav-item">
	<a class="nav-link js-scroll-trigger" href="#music">Music</a>
</li>
<li class="nav-item">
	<a class="nav-link js-scroll-trigger" href="#video">Video</a>
</li>
<li class="nav-item">
	<a class="nav-link js-scroll-trigger" href="#updates">Updates</a>
</li>
<li class="nav-item">
	<a class="nav-link js-scroll-trigger" href="#features">Features</a>
</li>
<li class="nav-item">
	<a class="nav-link js-scroll-trigger" href="#download">Download</a>
</li>