<?php
//Include the dashboard dropdown
include_once($QUICKBROWSE->TEMPLATE_ROOT . '/includes/nav/dashboard/dashboard.php');
?>
<li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="" id="dropdownDashboard" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
		Users
	</a>
	<div class="dropdown-menu" aria-labelledby="dropdownDashboard">
		<a class="dropdown-item" href="<?=$QUICKBROWSE->DOMAIN;?>/dashboard/users/index">Summary</a>
		<div class="dropdown-divider"></div>
		<a class="dropdown-item" href="<?=$QUICKBROWSE->DOMAIN;?>/dashboard/users/create">Create</a>
	</div>
</li>