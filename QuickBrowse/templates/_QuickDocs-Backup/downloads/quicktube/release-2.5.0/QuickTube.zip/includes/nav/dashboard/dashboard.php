<li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="" id="dropdownDashboard" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
		Dashboard
	</a>
	<div class="dropdown-menu" aria-labelledby="dropdownDashboard">
		<a class="dropdown-item" href="<?=$QUICKBROWSE->DOMAIN;?>/dashboard/index">Dashboard</a>
		<a class="dropdown-item" href="<?=$QUICKBROWSE->DOMAIN;?>/dashboard/account">Account</a>
		<a class="dropdown-item" href="<?=$QUICKBROWSE->DOMAIN;?>/dashboard/users/index">Users</a>
		<a class="dropdown-item" href="<?=$QUICKBROWSE->DOMAIN;?>/dashboard/blog/index">Blog</a>
	</div>
</li>