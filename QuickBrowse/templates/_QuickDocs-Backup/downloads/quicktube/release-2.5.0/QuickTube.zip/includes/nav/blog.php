<li class="nav-item">
	<a class="nav-link js-scroll-trigger" href="#page-bottom"><i class="far fa-caret-square-down"></i> Down</a>
</li>