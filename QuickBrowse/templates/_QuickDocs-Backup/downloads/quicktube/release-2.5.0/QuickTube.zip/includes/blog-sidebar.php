<?php
if($USER->is_logged_in() && (!isset($userdata) || empty($userdata)) ){
	$userdata = Array();
	foreach($USERS as $user){
		if($user['id'] == $USER->get_id()){
			$userdata = $user;
		}
	}
}
?>
<h2>Sidebar</h2>
<p class="lead">User</p>
<div class="jumbotron bg-light text-dark py-4 px-4">
	<?php
	if(!$USER->is_logged_in()){
		?>
		<label>You're not logged in.</label>
		<ul id="user" class="mb-0 pl-3">
			<li><a href="<?=$QUICKBROWSE->DOMAIN;?>/signup">Sign Up</a></li>
			<li><a href="<?=$QUICKBROWSE->DOMAIN;?>/signin">Sign In</a></li>
		</ul>
		<?php
	}else{
		?>
		<label>Hi, <?=$userdata['name'];?>.</label>
		<ul id="user" class="mb-0 pl-3">
			<li><a href="<?=$QUICKBROWSE->DOMAIN;?>/dashboard/account">Account</a></li>
			<li><a href="<?=$QUICKBROWSE->DOMAIN;?>/dashboard/index">Dashboard</a></li>
			<li><a href="<?=$QUICKBROWSE->DOMAIN;?>/logout">Logout</a></li>
		</ul>
		<?php
	}
	?>
</div>
<p class="lead">Updates</p>
<div class="jumbotron bg-light text-dark py-4 px-4">
	<label>Recent updates.</label>
	<ul id="updates" class="mb-0 pl-3">
		<?php
		$updates = Array();
		foreach($POSTS as $post){
			//Select all tagged posts with tag: update.
			if($post['tag'] == 'update'){
				//Save them to a new array called $updates for later reference.
				$updates[$post['id']] = $post;
				?>
				<li class="mb-3"><a href="<?=$QUICKBROWSE->DOMAIN;?>/blog/post/<?=$updates[$post['id']]['id'];?>"><?=$updates[$post['id']]['title'];?></a></li>
				<?php
			}
		}
		?>
	</ul>
</div>
<p class="lead">Blog</p>
<div class="jumbotron bg-light text-dark py-4 px-4">
	<label>Recent Posts.</label>
	<ul id="posts" class="mb-0 pl-3">
	<?php
	$recents = Array();
	foreach($POSTS as $post){
		if($post['tag'] == 'test'){
			//Dont do anything with the test posts
		}
		if($post['tag'] == 'update' || $post['tag'] == 'post'){
			$recents[$post['id']] = $post;
			?>
			<li class="mb-3"><a href="<?=$QUICKBROWSE->DOMAIN;?>/blog/post/<?=$recents[$post['id']]['id'];?>"><?=$recents[$post['id']]['title'];?></a></li>
			<?php
		}
	}
	?>
	</ul>
</div>