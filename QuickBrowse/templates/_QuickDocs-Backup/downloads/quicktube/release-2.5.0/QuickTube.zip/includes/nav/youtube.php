<li class="nav-item">
	<a class="nav-link js-scroll-trigger" href="#channel">Channel</a>
</li>