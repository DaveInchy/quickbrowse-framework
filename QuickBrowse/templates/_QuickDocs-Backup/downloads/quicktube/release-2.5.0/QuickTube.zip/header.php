<?php
//Get url and sub-directory data
$url_data 		= $PAGE->get_subdir_data();
$dir 			= $url_data['dir'];
$path 			= $url_data['path'];
$length 		= $url_data['length'];
$page 			= $dir[0];

//Register simple links without sub-directories.
$PAGE->set_link('signup', 'register.php');
$PAGE->set_link('sign-up', 'register.php');
$PAGE->set_link('signin', 'login.php');
$PAGE->set_link('sign-in', 'login.php');
$PAGE->set_link('log-in', 'login.php');
$PAGE->set_link('404', 'error.php');

//If current directory is post and the parent directory is blog, use the page as id
if($dir[1] == 'post' && $dir[2] == 'blog'){
	//Link current page (id) to a standard file.
	$PAGE->set_link($page		, 'post.php');
	//Save the page as content id.
	$PAGE->set_content_id($page);
}

//Register sub-directory links
if($dir[1] == 'video' && $dir[2] == 'youtube'){
	$PAGE->set_link($page		, 'video.php');
	$PAGE->set_content_id($page);
}
if($dir[1] == 'downloads'){
	$PAGE->set_link($page		, 'downloads.php');
	$PAGE->set_content_id($page);
}

//Register dashboard sub-directory links
if($dir[1] == 'dashboard'){
	$PAGE->set_link('index'		, $path[1] . 'dashboard.php');
	$PAGE->set_link('dashboard'	, $path[1] . 'dashboard.php');
	$PAGE->set_link('account'	, $path[1] . 'account.php');
	$PAGE->set_link('blog'		, $path[1] . 'blog.php');
	$PAGE->set_link('users'		, $path[1] . 'users.php');
}
if($dir[1] == 'blog' && $dir[2] == 'dashboard'){
	$PAGE->set_link('index'		, $path[2] . 'index.php');
	$PAGE->set_link('create'	, $path[2] . 'create.php');
	$PAGE->set_link('edit'		, $path[2] . 'edit.php');
	$PAGE->set_link('show'		, $path[2] . 'show.php');
	$PAGE->set_link('remove'	, $path[2] . 'remove.php');
}
if($dir[1] == 'users' && $dir[2] == 'dashboard'){
	$PAGE->set_link('index'		, $path[2] . 'index.php');
	$PAGE->set_link('create'	, $path[2] . 'create.php');
	$PAGE->set_link('edit'		, $path[2] . 'edit.php');
	$PAGE->set_link('show'		, $path[2] . 'show.php');
	$PAGE->set_link('remove'	, $path[2] . 'remove.php');
}
if($dir[2] == 'blog' && $dir[3] == 'dashboard'){
	$PAGE->set_link($page		, str_replace($dir[1] . '/', '', $path[3]) . $dir[1] . '.php');
	$PAGE->set_content_id($page);
}
if($dir[2] == 'users' && $dir[3] == 'dashboard'){
	$PAGE->set_link($page		, str_replace($dir[1] . '/', '', $path[3]) . $dir[1] . '.php');
	$PAGE->set_content_id($page);
}

//Reload created page links, and for the correct value when using $PAGE->get_page_file/name();
$PAGE->set_page();

//Load all data at once for later use.
$USERS = $DATA->data_read('users', Array('TYPE' => 'DATA_NEWEST'));
$POSTS = $DATA->data_read('posts', Array('TYPE' => 'DATA_NEWEST'));

//Load choose-able theme list
$THEMES = Array(
	'bootstrap',
	'cerulean',
	'cosmo',
	'cyborg',
	'darkly',
	'flatly',
	'journal',
	'litera',
	'lumen',
	'lux',
	'materia',
	'minty',
	'pulse',
	'sandstone',
	'simplex',
	'sketchy',
	'slate',
	'solar',
	'spacelab',
	'superhero',
	'united',
	'yeti'
);

//Load default or current theme
$THEME = $TEMPLATE->THEME;
if(isset($_SESSION['theme']) && !empty($_SESSION['theme'])){
	$THEME = $_SESSION['theme'];
}

//Set userdata for the one logged in if logged in and $userdata is not yet set.
if($USER->is_logged_in() && (!isset($userdata) || empty($userdata)) ){
	$userdata = Array();
	foreach($USERS as $user){
		if($USER->get_id() == $user['id']){
			$userdata = $user;
		}
	}
}
?>