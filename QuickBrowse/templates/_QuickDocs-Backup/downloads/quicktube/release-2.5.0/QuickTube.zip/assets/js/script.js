$(function () {
	var w = (1110 - 52) / 4;
	var toolbarOptions = [
		['bold', 'italic', 'underline', 'strike'],        // toggled buttons
		['blockquote', 'code-block'],

		[{ 'header': 1 }, { 'header': 2 }],               // custom button values
		[{ 'list': 'ordered'}, { 'list': 'bullet' }],
		[{ 'script': 'sub'}, { 'script': 'super' }],      // superscript/subscript
		[{ 'indent': '-1'}, { 'indent': '+1' }],          // outdent/indent
		[{ 'direction': 'rtl' }],                         // text direction

		[{ 'size': ['small', false, 'large', 'huge'] }],  // custom dropdown
		[{ 'header': [1, 2, 3, 4, 5, 6, false] }],

		[{ 'color': [] }, { 'background': [] }],          // dropdown with defaults from theme
		[{ 'font': [] }],
		[{ 'align': [] }],

		['clean']                                         // remove formatting button
	];
	$('[data-toggle="popover"]').popover();
	$('[data-toggle="popover"]').css('cursor', 'pointer');

	$('[data-table="dashboard"]').DataTable({
		"pagingType": "full_numbers",
		"autoWidth": false,
		"columnDefs": [
			{"width": w.toString(), "targets": [1, 2, 3]} //Somehow this fixes the overflow bug.
		],
		"ordering": false,
		"lengthMenu": [5, 10, 25, 50, 100]
	});
	$('.dataTables_length').addClass('bs-select');
	var quill = new Quill('[id="form_content"]', {
		modules: {
			toolbar: toolbarOptions
		},
		theme: 'snow'
	});
	$('[name="form_submit"]').click(function() {
		var c = $('[class="ql-editor"]').html();
		$('[name="form_content"]').val(c);
	});
})