<?php

//------------------------\\//------------------------------------------------\\//------------------------------------------------\\//------------------------\\
// Author: 		DoOnline
// Contact: 	contact@doonline.nl
// Version: 	1.1
// Class: 		Display() (display.class.php)
// Required: 	class Functions, global $QUICKBROWSE, global $YOUTUBE
// Location:	Template
//------------------------\\//------------------------------------------------\\//------------------------------------------------\\//------------------------\\

class Display extends Functions{
	
	function lipsum(){
		return 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam pellentesque velit at vulputate cursus. Mauris vel turpis tortor. Nulla facilisi. Donec augue velit, blandit vitae consequat eu, gravida nec tellus. Donec tempus dui eu venenatis hendrerit. Morbi ac pretium arcu, et faucibus est. Cras congue non ante nec maximus. Nulla venenatis vel ipsum vehicula eleifend. Pellentesque consectetur mollis metus, sed congue enim. Aliquam fermentum neque eu mattis consectetur. Ut bibendum rutrum est eu gravida. Sed non consequat mi. ';
	}
	
	function uploads_from_playlist($items, $limit){
		global $QUICKBROWSE;
		global $YOUTUBE;
		
		$count = 0;
		try{
			foreach($items as $upload){
				$count++;
				if($count <= $limit){
					$uploadId = $upload['snippet']['resourceId']['videoId'];
					$videodata = $YOUTUBE->get_raw_data('video', $uploadId);
					if(!$videodata){
						$this->ERROR = $YOUTUBE->ERROR;
						return false;
					}
					?>
					<div class="col-lg-3 mt-3" style="padding: 5px; padding-top: 0px; padding-bottom: 0px;">
					  <a class="my-0 mx-0 m-0" href="<?=$QUICKBROWSE->DOMAIN;?>/youtube/video/<?=$uploadId;?>">
						  <div class="jumbotron embed-responsive embed-responsive-16by9 bg-light" style="background-image: url('<?=$videodata['thumbnail_url'];?>'); background-size: cover; background-position: center; ">
						  </div>
					  </a>
					  <h6 class="text-center text-uppercase text-truncate font-weight-bold" style="margin-top: -20px;"><?=$videodata['title'];?></h6>
					</div>
					<?php
				}
			}
		}catch(Exception $e){
			$this->ERROR = $e->getMessage();
			return false;
		}
		return true;
	}
	
	function blog_posts($posts, $users, $tag = "", $limit = '3'){
		global $QUICKBROWSE;
		$count = 0;
		try{
			foreach($posts as $post){
				//check if the post tag is the same as the given argument
				$tag_match = true;
				if(!empty($tag)){
					if($tag != $post['tag']){
						$tag_match = false;
					}
				}
				if($tag_match && $count < $limit){
					//Add count
					$count++;
					//find author name
					foreach($users as $user){
						if($user['id'] == $post['author']){
							$author = $user['name'];
							break;
						}
					}
					//format date from timestamp
					$date = date('F jS, Y', $post['timestamp']);
					//output all posts.
					?>
					<div id="post_<?=$post['id'];?>" class="jumbotron bg-light py-4 pb-5 text-left">
						<img class="img-fluid my-2" style="border: 0px solid white; border-radius: .5em;" src="<?=$post['thumbnail'];?>" />
						<a class="text-dark" href="<?=$QUICKBROWSE->DOMAIN;?>/blog/post/<?=$post['id'];?>"><h3><?=$post['title'];?></h3></a>
						<p class="text-justify">
							<?=$post['content'];?>
							<a class="btn btn-outline-primary btn-sm float-right mt-5 font-weight-bold" href="<?=$QUICKBROWSE->DOMAIN;?>/blog/post/<?=$post['id'];?>">Read</a>
						</p>
						<p class="text-dark font-weight-bold my-1">Author: <span class="text-secondary font-weight-normal"><?=$author;?></span></p>
						<p class="text-dark font-weight-bold my-1">Posted on: <span class="text-secondary font-weight-normal"><?=$date;?></span></p>
						<p class="text-dark font-weight-bold my-1">Tag: <span class="text-secondary font-weight-normal"><?=$post['tag'];?></span></p>
					</div>
					<?php
				}
			}
		}catch(Exception $e){
			$this->ERROR = $e->getMessage();
			return false;
		}
		return true;
	}
	
	function feature_video($vid){
		global $QUICKBROWSE;
		global $YOUTUBE;
		
		$videodata				= $YOUTUBE->get_raw_data('video', $vid);
		$videodata['youtube'] 	= $YOUTUBE->get_raw_data('youtube', $vid);
		if(!$videodata){
			$this->ERROR = $YOUTUBE->ERROR;
			return false;
		}
		?>
		<h2 class="text-truncate mb-3"><?=$videodata['title'];?></h2>
		<div class="embed-responsive embed-responsive-16by9 text-center">
			<iframe class="embed-responsive-item" src="https://www.youtube.com/embed/<?=$vid;?>?autoplay=1&controls=0&enablejsapi=1&fs=0&modestbranding=1&start=0&iv_load_policy=3" frameborder="0" allowfullscreen></iframe>
		</div>
		<div class="row">
			<div class="col-8">
				<h3 class="mt-3 text-left">
					Author: <a class="text-secondary" href="<?=$videodata['author_url'];?>"><?=$videodata['author_name'];?></a>
				</h3>
			</div>
			<div class="col-4">
				<h3 class="mt-3 text-right">
					Views: <span class="text-secondary"><?=$videodata['youtube']['items'][0]['statistics']['viewCount'];?></span>
				</h3>
			</div>
		</div>
		<?php
		return $videodata;
	}
	
	function list_group_themes($themes_array, $active){
		?>
		<div class='list-group text-center'>
		<?php
			foreach($themes_array as $theme){
				if($active == $theme){
					?><a href='<?=$QUICKBROWSE->DOMAIN;?>/theme?set=<?=$theme;?>' class='list-group-item list-group-item-action font-weight-bold text-uppercase active'><?=$theme;?></a><?php
				}else{
					?><a href='<?=$QUICKBROWSE->DOMAIN;?>/theme?set=<?=$theme;?>' class='list-group-item list-group-item-action font-weight-bold text-uppercase'><?=$theme;?></a><?php
				}
			}
		?>
		</div>
		<?php
	}
	
	function table_blog_posts($posts, $users){
		global $QUICKBROWSE;
		try{
			?>
			<table data-table="dashboard" class="table table-responsive table-striped table-hover" cellspacing="1" width="100%">
			  <thead>
				<tr class="table-primary">
				  <th scope="col" class="bg-primary"><a href="./create/"><h3 class="my-auto text-center text-light"><i class="fas fa-folder-plus"></i></h3></a></th>
				  <th scope="col"><h3 class="my-auto">Title</h3></th>
				  <th scope="col"><h3 class="my-auto">Tag</h3></th>
				  <th scope="col"><h3 class="my-auto">Author</h3></th>
				  <th scope="col"><h3 class="my-auto">Date</h3></th>
				  <th scope="col"><h3 class="my-auto text-center">Update</h3></th>
				  <th scope="col"><h3 class="my-auto text-center">Delete</h3></th>
				</tr>
			  </thead>
			  <tbody>
				<?php
				foreach($posts as $post){
					//find author name
					foreach($users as $user){
						if($user['id'] == $post['author']){
							$author = $user['name'];
							break;
						}
					}
					//format date from timestamp
					$date = date("d-m-Y H:i:s", $post['timestamp']);
					?>
					<tr id="row_<?=$post['id'];?>">
					  <th scope="row" class="bg-primary"><p class="lead my-auto text-center font-weight-bold text-light"><?=$post['id'];?></p></th>
					  <td for="Title"><p class="lead my-auto"><?=$post['title'];?></p></td>
					  <td for="Tag"><p class="lead my-auto"><?=$post['tag'];?></p></td>
					  <td for="Author"><p class="lead my-auto"><?=$author;?></p></td>
					  <td for="Date"><p class="lead my-auto"><?=$date;?></p></td>
					  <td for="Update" class="bg-success"><a href="./edit/<?=$post['id'];?>"><p class="lead my-auto text-center text-light"><i class="fas fa-pen"></i></p></td>
					  <td for="Delete" class="bg-danger"><a href="./remove/<?=$post['id'];?>"><p class="lead my-auto text-center text-light"><i class="fas fa-trash"></i></p></td>
					</tr>
					<?php
				}
				?>
			  </tbody>
			  <!--<tfoot>
				<tr class="table-primary">
				  <th scope="col" class="bg-primary"><a href="./create"><h3 class="my-auto text-center text-light"><i class="fas fa-folder-plus"></i></h3></a></th>
				  <th scope="col"><h3 class="my-auto">Title</h3></th>
				  <th scope="col"><h3 class="my-auto">Tag</h3></th>
				  <th scope="col"><h3 class="my-auto">Author</h3></th>
				  <th scope="col"><h3 class="my-auto">Date</h3></th>
				  <th scope="col"><h3 class="my-auto text-center">Update</h3></th>
				  <th scope="col"><h3 class="my-auto text-center">Delete</h3></th>
				</tr>
			  </tfoot>-->
			</table>
			<?php
		}catch(Exception $e){
			$this->ERROR = $e->getMessage();
			return false;
		}
		return true;
	}
	
	function table_registered_users($users){
		global $QUICKBROWSE;
		try{
			?>
			<table data-table="dashboard" class="table table-responsive table-striped table-hover" cellspacing="1" width="100%">
			  <thead>
				<tr class="table-primary">
				  <th scope="col" class="bg-primary"><a href="./create/"><h3 class="my-auto text-center text-light"><i class="fas fa-user-plus"></i></h3></a></th>
				  <th scope="col"><h3 class="my-auto">Name</h3></th>
				  <th scope="col"><h3 class="my-auto">Email</h3></th>
				  <th scope="col"><h3 class="my-auto">Password</h3></th>
				  <th scope="col"><h3 class="my-auto text-center">Update</h3></th>
				  <th scope="col"><h3 class="my-auto text-center">Delete</h3></th>
				</tr>
			  </thead>
			  <tbody>
				<?php
				foreach($users as $user){
					?>
					<tr>
					  <th scope="row" class="bg-primary"><p class="lead my-auto text-center font-weight-bold text-light"><?=$user['id'];?></p></th>
					  <td for="Name"><p class="lead my-auto"><?=$user['name'];?></p></td>
					  <td for="Email"><p class="lead my-auto"><?=$user['email'];?></p></td>
					  <td for="Password"><p class="lead my-auto"><?=md5($user['password']);?></p></td>
					  <td for="Update" class="bg-success"><a href="./edit/<?=$user['id'];?>"><p class="lead my-auto text-center text-light"><i class="fas fa-pen"></i></p></td>
					  <td for="Delete" class="bg-danger"><a href="./remove/<?=$user['id'];?>"><p class="lead my-auto text-center text-light"><i class="fas fa-trash"></i></p></td>
					</tr>
					<?php
				}
				?>
			  </tbody>
			  <!--<tfoot>
				<tr class="table-primary">
				  <th scope="col" class="bg-primary"><a href="./create"><h3 class="my-auto text-center text-light"><i class="fas fa-user-plus"></i></h3></a></th>
				  <th scope="col"><h3 class="my-auto">Name</h3></th>
				  <th scope="col"><h3 class="my-auto">Email</h3></th>
				  <th scope="col"><h3 class="my-auto">Password</h3></th>
				  <th scope="col"><h3 class="my-auto text-center">Update</h3></th>
				  <th scope="col"><h3 class="my-auto text-center">Delete</h3></th>
				</tr>
			  </tfoot>-->
			</table>
			<?php
		}catch(Exception $e){
			$this->ERROR = $e->getMessage();
			return false;
		}
		return true;
	}
	
	function form_blog_post($is_update, $id = 0){
		global $DATA;
		global $PAGE;
		global $USER;
		try{
			$form['id'] = $id;
			if($is_update && $id != 0){
				$form['type'] = 'update';
				$posts = $DATA->data_read('posts', Array('TYPE' => 'DATA_NEWEST'));
				foreach($posts as $post){
					if($post['id'] == $id){
						$form = $post;
					}
				}
			}else{
				$form['type'] = 'create';
				$form['title'] = '';
				$form['thumbnail'] = '';
				$form['content'] = '';
				$form['tag'] = '';
			}
			if(isset($_POST['form_submit'])){
				if($is_update){
					$data = Array(
						'title' 	=> $_POST['form_title'],
						'thumbnail' => $_POST['form_thumbnail'],
						'tag' 		=> $_POST['form_tag'],
						'content' 	=> $_POST['form_content']
					);
					var_dump($data);
					if(!$DATA->data_update($data, 'posts', $id)){
						die($DATA->ERROR);
					}
					$PAGE->redirect('/blog/post/' . $id);
				}else{
					$data = Array(
						'title' 	=> $_POST['form_title'],
						'thumbnail' => $_POST['form_thumbnail'],
						'tag' 		=> $_POST['form_tag'],
						'content' 	=> $_POST['form_content'],
						'author' 	=> $USER->get_id(),
						'timestamp' => time()
					);
					var_dump($data);
					$id = $DATA->data_create($data, 'posts');
					if(!$id){
						die($DATA->ERROR);
					}
					$PAGE->redirect('/blog/post/' . $id);
				}
			}
			?>
			<form class="row" method="POST">
				<?php
				if($is_update){
				?>
				<div class="input-group mb-3">
				  <div class="input-group-prepend d-none d-md-flex col-sm-3">
					<span class="input-group-text" style="width: 100%;" id="form_<?=$form['type'];?>_id">ID</span>
				  </div>
				  <input name="form_id" value="<?=$form['id'];?>" type="number" class="form-control" placeholder="0" aria-label="ID" aria-describedby="form_<?=$form['type'];?>_id">
				</div>
				<?php
				}
				?>
				<div class="input-group mb-3">
				  <div class="input-group-prepend d-none d-md-flex col-sm-3">
					<span class="input-group-text" style="width: 100%;" id="form_<?=$form['type'];?>_title">Title</span>
				  </div>
				  <input name="form_title" value="<?=$form['title'];?>" type="text" class="form-control" placeholder="Hello world" aria-label="Title" aria-describedby="form_<?=$form['type'];?>_title">
				</div>
				<div class="input-group mb-3">
				  <div class="input-group-prepend d-none d-md-flex col-sm-3">
					<span class="input-group-text" style="width: 100%;" id="form_<?=$form['type'];?>_thumbnail">Thumbnail</span>
				  </div>
				  <input name="form_thumbnail" value="<?=$form['thumbnail'];?>" type="text" class="form-control" placeholder="https://i.imgur.com/XzdNH9F.png" aria-label="thumbnail" aria-describedby="form_<?=$form['type'];?>_thumbnail">
				</div>
				<div class="input-group mb-3">
				  <div class="input-group-prepend d-none d-md-flex col-sm-3">
					<span class="input-group-text" style="width: 100%;" id="form_<?=$form['type'];?>_tag">Tag</span>
				  </div>
				  <input name="form_tag" value="<?=$form['tag'];?>" type="text" class="form-control" placeholder="post/update/announcement" aria-label="tag" aria-describedby="form_<?=$form['type'];?>_tag">
				</div>
				<div class="input-group mb-3 col-sm-12 pr-0">
				  <!--<textarea style="min-height: 25vh;" name="form_content" class="form-control" placeholder="<?=$this->lipsum();?>" aria-label="Content" aria-describedby="form_<?=$form['type'];?>_content">
					<?=$form['content'];?>
				  </textarea>-->
				  <textarea class="d-none" name="form_content"></textarea>
				  <div id="form_content" class="form-control p-0 m-0"  aria-label="Content" aria-describedby="form_<?=$form['type'];?>_content">
					<?=$form['content'];?>
				  </div>
				</div>
				<button type="submit" name="form_submit" style="margin-top: 75px;" class="ml-3 btn btn-primary btn-block">Save</button>
			</form>
			<?php
		}catch(Exception $e){
			$this->ERROR = $e->getMessage();
			return false;
		}
		return true;
	}
	
	function form_users($is_update, $id = 0){
		global $DATA;
		global $PAGE;
		global $USER;
		try{
			$form['id'] = $id;
			if($is_update && $id != 0){
				$form['type'] = 'update';
				$users = $DATA->data_read('users', Array('TYPE' => 'DATA_NEWEST'));
				foreach($users as $user){
					if($user['id'] == $id){
						$form = $user;
					}
				}
			}else{
				$form['type'] = 'create';
				$form['name'] = '';
				$form['email'] = '';
				$form['password'] = '';
			}
			if(isset($_POST['form_submit'])){
				if($is_update){
					$data = Array(
						'name' => $_POST['form_name'],
						'email' => $_POST['form_email'],
						'password' => $_POST['form_password']
					);
					var_dump($data);
					if(!$DATA->data_update($data, 'users', $id)){
						die($DATA->ERROR);
					}
					$PAGE->redirect('/dashboard/users/index');
				}else{
					$data = Array(
						'name' => $_POST['form_name'],
						'email' => $_POST['form_email'],
						'password' => $_POST['form_password']
					);
					var_dump($data);
					$id = $DATA->data_create($data, 'users');
					if(!$id){
						die($DATA->ERROR);
					}
					$PAGE->redirect('/dashboard/users/index');
				}
			}
			?>
			<form class="row" method="POST">
				<?php
				if($is_update){
				?>
				<div class="input-group mb-3">
				  <div class="input-group-prepend d-none d-md-flex col-sm-3">
					<span class="input-group-text" style="width: 100%;" id="form_<?=$form['type'];?>_id">ID</span>
				  </div>
				  <input name="form_id" value="<?=$form['id'];?>" type="number" class="form-control" placeholder="0" aria-label="ID" aria-describedby="form_<?=$form['type'];?>_id">
				</div>
				<?php
				}
				?>
				<div class="input-group mb-3">
				  <div class="input-group-prepend d-none d-md-flex col-sm-3">
					<span class="input-group-text" style="width: 100%;" id="form_<?=$form['type'];?>_name">Name</span>
				  </div>
				  <input name="form_name" value="<?=$form['name'];?>" type="text" class="form-control" placeholder="Ahmed Mohammed" aria-label="name" aria-describedby="form_<?=$form['type'];?>_name">
				</div>
				<div class="input-group mb-3">
				  <div class="input-group-prepend d-none d-md-flex col-sm-3">
					<span class="input-group-text" style="width: 100%;" id="form_<?=$form['type'];?>_email">Email</span>
				  </div>
				  <input name="form_email" value="<?=$form['email'];?>" type="email" class="form-control" placeholder="mail@domain.com" aria-label="email" aria-describedby="form_<?=$form['type'];?>_email">
				</div>
				<div class="input-group mb-3">
				  <div class="input-group-prepend d-none d-md-flex col-sm-3">
					<span class="input-group-text" style="width: 100%;" id="form_<?=$form['type'];?>_password">Password</span>
				  </div>
				  <input name="form_password" value="<?=$form['password'];?>" type="password" class="form-control" placeholder="Password" aria-label="password" aria-describedby="form_<?=$form['type'];?>_password">
				</div>
				<button type="submit" name="form_submit" style="margin-top: 75px;" class="ml-3 btn btn-primary btn-block">Save</button>
			</form>
			<?php
		}catch(Exception $e){
			$this->ERROR = $e->getMessage();
			return false;
		}
		return true;
	}
	
}

?>