<?php

//IMPORTANT: This file is required, and the class needs to be "TemplateSettings" to make sure its valid.
//IMPORTANT: These settings will be included into QuickBrowse by default as "$TEMPLATE".

//TIP: You can call these settings with for example: $TEMPLATE->VERSION.
//TIP: Look on https://quickbrowse.doonline.nl/ for the documentation and how to create settings for your template.

class TemplateSettings{
	
	//Template Information. (Default and required)
	public $VERSION 			= 'release-2.5.0';
	public $TITLE 				= 'QuickTube';
	public $DESCRIPTION 		= 'Feature your Youtube channel with Youtube API V3.<br>Intregated with PHP 7 and Powered by QuickBrowse';
	public $AUTHOR 				= 'DoOnline';
	public $AUTHOR_URL			= 'https://doonline.nl';
	public $AUTHOR_EMAIL		= 'contact@doonline.nl';
	
	//Youtube Settings.
	public $CHANNELID 			= 'UC-lHJZR3Gqxm24_Vd_AJ5Yw';
	public $APIKEY				= 'getyourownapikeyfromgoogle';
	public $FEATURED			= 'PhI3NfXkvVM';
	
	//Theme Settings. 
	public $THEME				= 'bootstrap';
}

?>
