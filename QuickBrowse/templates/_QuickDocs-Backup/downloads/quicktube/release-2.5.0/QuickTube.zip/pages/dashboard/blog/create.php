<?php
//Include whats on the dashboard page like header.
include_once($QUICKBROWSE->TEMPLATE_ROOT . '/pages/dashboard/blog.php');
?>
<section id="create_post">
	<div class="container">
		<div class="col-lg-8 mx-auto">
			<h1>Create</h1>
			<p class="lead">Write a blog post.</p>
			<?php
			//Display form create blog post.
			$DISPLAY->form_blog_post(false);
			?>
		</div>
	</div>
</section>