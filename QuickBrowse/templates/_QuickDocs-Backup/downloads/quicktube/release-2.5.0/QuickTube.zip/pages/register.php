<?php
$error = 'You can not register right now.';
?>
<section id="register">
	<div style="padding-top: 50px; padding-bottom: 50px;" class="container">
	  <div class="col-xs-12">
		<center>
		  <div class="col-md-4 col-sm-12 jumbotron bg-light text-dark">
			<h1 class="text-uppercase">Sign up</h1>
			<p style="color: red;"><?=$error;?></p>
			<form method="POST">

			  <div class="form-group">
				<input class="form-control" type="text" name="form_name" placeholder="Choose a username"></input>
			  </div>
			  
			  <div class="form-group">
				<input class="form-control" type="email" name="form_email" placeholder="Choose a valid e-mail address"></input>
			  </div>
			  
			  <div class="form-group">
				<input class="form-control" type="password" name="form_password" placeholder="Choose a password"></input>
			  </div>
			  <div class="form-group">
				<input class="form-control" type="password" name="form_password_confirm" placeholder="Confirm your password"></input>
			  </div>

			  <button class="btn btn-block btn-outline-primary" type="submit" name="btn_register">Register</button>
			</div>
		  </div>
		</center>
	  </div>
	</div>
</section>