<?php
if($USER->is_logged_in()){
	$USER->logout();
}
header('Location: ' . $QUICKBROWSE->DOMAIN . '/index');
exit;
?>