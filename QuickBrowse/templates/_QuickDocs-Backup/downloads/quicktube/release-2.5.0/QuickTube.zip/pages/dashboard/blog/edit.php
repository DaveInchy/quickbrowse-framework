<?php
//Include whats on the dashboard page like header.
include_once($QUICKBROWSE->TEMPLATE_ROOT . '/pages/dashboard/blog.php');
?>
<section id="edit_post">
	<div class="container">
		<div class="col-lg-8 mx-auto">
			<h1>Update</h1>
			<p class="lead">Edit blog post id: <?=$PAGE->get_content_id();?>.</p>
			<?php
			//Display form create blog post.
			$DISPLAY->form_blog_post(true, $PAGE->get_content_id());
			?>
		</div>
	</div>
</section>