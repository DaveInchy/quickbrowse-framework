<section id="video">
	<div class="container">
		<?php
		//Display video
		$video = $DISPLAY->feature_video($vid);
		if(!$video){
			?><p class="lead text-danger"><?=$DISPLAY->ERROR;?></p><?php
		}
		?>
	</div>
</section>

<?php
if($QUICKBROWSE->DEBUG == "on"){
?>
<section id="debug" class="bg-light">
	<div class="container">
		<h2 class="mb-3">Debug</h2>
		<div class="jumbotron bg-light">
			<pre>
				<?php print_r($video); ?>
			</pre>
		</div>
	</div>
</section>
<?php
}
?>