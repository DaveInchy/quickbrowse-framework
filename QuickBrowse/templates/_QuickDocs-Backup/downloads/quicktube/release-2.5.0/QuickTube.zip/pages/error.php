<header id="error" class="bg-light">
	<div class="container">
	  <h1 class="text-center font-weight-bold" style="font-size: 186px;">404</h1>
	</div>
</header>

<section id="error-message" class="text-center">
	<div class="container">
	  <h2 class="lead">... <?=ucfirst($error);?> ...</h2>
	</div>
</section>