<section id="post">
	<div class="container">
		<div class="row">
			<div class="col-lg-5 ml-auto">
				<h1><?=$postdata['title'];?></h1>
				<p class="lead">Posted on <?=$postdata['date'];?> by <?=$postdata['author_name'];?></p>
				<img class="img-fluid my-2" style="border: 0px solid white; border-radius: .5em;" src="<?=$postdata['thumbnail'];?>" />
				<p class="mt-3 text-dark text-justify lead">
					<?=$postdata['content'];?>
				</p>
			</div>
			<div class="col-lg-3 mr-auto">
				<?php
				//Include sidebar
				include_once($QUICKBROWSE->TEMPLATE_ROOT . '/includes/blog-sidebar.php');
				?>
			</div>
		</div>
	</div>
</section>