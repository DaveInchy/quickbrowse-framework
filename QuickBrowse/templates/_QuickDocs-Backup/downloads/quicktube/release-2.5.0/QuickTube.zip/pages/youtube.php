<header id="youtube" class="bg-light">
	<div class="container text-center">
	  <h1 class="font-weight-bold">try now!</h1>
	  <?php
	  if(!$isset){
	  ?>
		<p class="text-danger font-weight-bold"><?=$error;?></p>
	  <?php  
	  }
	  ?>
	  <form method="POST">
		<div class="input-group my-3 col-md-8 mx-auto">
		  <div class="input-group-prepend d-none d-md-block">
			<span style="max-height: 45px;" class="input-group-text bg-primary text-light" id="youtube-channel-prefix">https://youtube.com/channel/</span>
		  </div>
		  <input name="channel-id" type="text" class="form-control" id="youtube-channel-id" placeholder="UC-lHJZR3Gqxm24_Vd_AJ5Yw" value="<?=$TEMPLATE->CHANNELID;?>" aria-describedby="youtube-channel-prefix">
		  <div class="input-group-append input-group-btn">
			<button style="max-height: 45px; border-top-right-radius: .25rem; border-bottom-right-radius: .25rem;" name="submit-channel" type="submit" class="btn btn-sm btn-primary" id="youtube-channel-submit">Go</button>
		  </div>
		</div>
	  </form>
	  <p class="lead">Please fill in any "channel id" and click "go" to request your channel's information.</p>
	</div>
</header>

<?php
	if($isset){
	?>
	<section id="channel">
		<div class="container">
		  <div class="row">
			<div class="col-12 mb-5">
			  <h2 class="text-center">Youtube channel</h2>
			  <p class="lead text-center">Personal Youtube channel information based on given channel id.</p>
			</div>
		  </div>
		  <!-- Channel information -->
		  <div class="row">
			<div style="width: 100%;" class="jumbotron bg-light text-center">
				<img class="mx-auto border-light" src="<?=$_SESSION['channel']['thumbnail']['url'];?>" style="border-radius: 100px; border: solid 2px" width="200px" height="200px"/>
				<h3 class="my-3 font-weight-bold"><?=$_SESSION['channel']['title'];?></h3>
				<p class="lead"><?=$_SESSION['channel']['description'];?></p>
			</div>
		  </div>
		  <!-- Channel content -->
		  <div class="row">
			<div class="col-12">
				<div class="row mb-5" style="margin-left: -20px; margin-right: -20px;">
					<?php
					//Display items from channel uploads
					$DISPLAY->uploads_from_playlist($uploads, $request_limit);
					?>
				</div>
			</div>
		  </div>
		  <!-- Channel statistics -->
		  <div class="row">
			<div class="col-md-4 pl-0">
				<div class="jumbotron text-center bg-light">
					<h3 class="py-0 my-0 font-weight-bold"><?=$_SESSION['channel']['stats']['videoCount'];?></h3>
					<br>
					<p class="py-0 my-0 text-center">Videos</p>
				</div>
			</div>
			<div class="col-md-4">
				<div class="jumbotron text-center bg-light">
					<h3 class="py-0 my-0 font-weight-bold"><?=$_SESSION['channel']['stats']['subscriberCount'];?></h3>
					<br>
					<p class="py-0 my-0 text-center">Subscribers</p>
				</div>
			</div>
			<div class="col-md-4 pr-0">
				<div class="jumbotron text-center bg-light">
					<h3 class="py-0 my-0 font-weight-bold"><?=$_SESSION['channel']['stats']['viewCount'];?></h3>
					<br>
					<p class="py-0 my-0 text-center">Views</p>
				</div>
			</div>
		  </div>
		  <?php
			if($QUICKBROWSE->DEBUG == 'on'){
		  ?>
		  <!-- Debug info -->
		  <div class="row">
			<h2 class="mt-5">Debug<br><p class="lead mb-3"><?=$info;?></p></h2>
			
			<div style="width: 100%;" class="jumbotron bg-light">
				<pre>
				<?php print_r($_SESSION['channel']); ?>
				</pre>
			</div>
		  </div>
		  <?php
			}
		  ?>
		</div>
	</section>
	<?php
	}else{
	?>
	<section id="youtube-videos">
		<div class="container">
		  <div class="row">
			<div class="col-lg-8 text-center mx-auto mb-5">
			  <h2>Example Youtube Playlists</h2>
			  <p class="lead">Here are some example playlists you can display within your website.</p>
			</div>
		  </div>
		  <div class="row">
			<div class="col-12 mt-5 text-center">
				<h5>Ultimate Disney Songs</h5>
			</div>
			<?php
				//Show items from uploads with a limit
				$DISPLAY->uploads_from_playlist($disney, $limit);
			?>
		  </div>
		  <div class="row">
			<div class="col-12 mt-5 text-center">
				<h5>Timeless Memes</h5>
			</div>
			<?php
				//Show items from uploads with a limit
				$DISPLAY->uploads_from_playlist($memes, $limit);
			?>
		  </div>
		  <div class="row">
			<div class="col-12 mt-5 text-center">
				<h5>Tonight Show</h5>
			</div>
			<?php
				//Show items from uploads with a limit
				$DISPLAY->uploads_from_playlist($nightshow, $limit);
			?>
		  </div>
		</div>
	</section>
	<?php
	}
?>