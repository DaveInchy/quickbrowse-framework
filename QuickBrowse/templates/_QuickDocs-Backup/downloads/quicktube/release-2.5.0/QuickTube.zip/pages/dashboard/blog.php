<header id="page-top" class="bg-light">
	<div class="container text-center">
		<h1>Blog</h1>
		<p class="lead">You can manage your blog right here.</p>
	</div>
</header>