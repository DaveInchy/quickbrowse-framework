<header id="page-top" class="bg-light">
	<div class="container text-center">
		<h1>Dashboard</h1>
		<p class="lead">Welcome <?=$userdata['name'];?>, this is your website's dashboard.</p>
	</div>
</header>

<section id="statistics">
	<div class="container text-center">
		<div class="col-lg-8 mx-auto">
			<h2>Website Statistics</h2>
			<p class="lead">A little bit of information.</p>
			<div class="row">
				<div class="col-lg-4 col-md-6 col-sm-12">
					<a href="<?=$QUICKBROWSE->DOMAIN;?>/dashboard/users/index">
					<div class="jumbotron bg-light text-center">
						<h3 class="py-0 px-0 my-0 font-weight-bold"><?=$users_count;?></h3>
						<p class="lead py-0 px-0 my-0">Users</p>
					</div>
					</a>
				</div>
				
				<div class="col-lg-4 col-md-6 col-sm-12">
					<a href="<?=$QUICKBROWSE->DOMAIN;?>/dashboard/blog/index">
					<div class="jumbotron bg-light text-center">
						<h3 class="py-0 px-0 my-0 font-weight-bold"><?=$posts_count;?></h3>
						<p class="lead py-0 px-0 my-0">Posts</p>
					</div>
					</a>
				</div>
				
				<div class="col-lg-4 col-md-6 col-sm-12">
					<div class="jumbotron bg-light text-center">
						<h3 class="py-0 px-0 my-0 font-weight-bold">4</h3>
						<p class="lead py-0 px-0 my-0">Comments</p>
					</div>
				</div>
				
				<div class="col-lg-4 col-md-6 col-sm-12">
					<div class="jumbotron bg-light text-center">
						<h3 class="py-0 px-0 my-0 font-weight-bold text-truncate"><?=$view_count;?></h3>
						<p class="lead py-0 px-0 my-0">Views</p>
					</div>
				</div>
				
				<div class="col-lg-4 col-md-6 col-sm-12">
					<div class="jumbotron bg-light text-center">
						<h3 class="py-0 px-0 my-0 font-weight-bold text-truncate"><?=$subscriber_count;?></h3>
						<p class="lead py-0 px-0 my-0">Subscribers</p>
					</div>
				</div>
				
				<div class="col-lg-4 col-md-6 col-sm-12">
					<div class="jumbotron bg-light text-center">
						<h3 class="py-0 px-0 my-0 font-weight-bold text-truncate"><?=$video_count;?></h3>
						<p class="lead py-0 px-0 my-0">Videos</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<section id="updates" class="bg-light">
	<div class="container">
		<div class="row">
			<div class="col-lg-5 ml-auto">
			  <h2>Updates</h2>
			  <p class="lead">Recent updates that've been uploaded to the blog.</p>
			  <?php
			  //Display limited blog posts tagged with 'update'.
			  $DISPLAY->blog_posts($POSTS, $USERS, 'update', 2);
			  ?>
			</div>
			<div class="col-lg-3 mr-auto">
			  <?php
			  //Include sidebar
			  include_once($QUICKBROWSE->TEMPLATE_ROOT . '/includes/blog-sidebar.php');
			  ?>
			</div>
		</div>
	</div>
</section>