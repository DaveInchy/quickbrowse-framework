<?php
//Include whats on the dashboard page like header.
include_once($QUICKBROWSE->TEMPLATE_ROOT . '/pages/dashboard/blog.php');
?>
<section id="remove">
	<div class="container text-center">
		<h1>Removing post <?=$PAGE->get_content_id();?></h1>
		<p class="lead">Are you sure you want to remove post id: <?=$PAGE->get_content_id();?>.</p>
		<div class="row">
			<div class="col-6">
				<a href="./<?=$PAGE->get_content_id();?>?action=no" class="btn btn-danger float-right">No</a>
			</div>
			<div class="col-6">
				<a href="./<?=$PAGE->get_content_id();?>?action=yes" class="btn btn-success float-left">Yes</a>
			</div>
		</div>
	</div>
</section>