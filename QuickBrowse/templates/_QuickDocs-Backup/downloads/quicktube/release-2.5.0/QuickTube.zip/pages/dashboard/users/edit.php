<?php
//Include whats on the dashboard page like header.
include_once($QUICKBROWSE->TEMPLATE_ROOT . '/pages/dashboard/users.php');
?>
<section id="edit_user">
	<div class="container">
		<div class="col-lg-8 mx-auto">
			<h1>Update</h1>
			<p class="lead">Edit user id: <?=$PAGE->get_content_id();?>.</p>
			<?php
			//Display form create blog post.
			$DISPLAY->form_users(true, $PAGE->get_content_id());
			?>
		</div>
	</div>
</section>