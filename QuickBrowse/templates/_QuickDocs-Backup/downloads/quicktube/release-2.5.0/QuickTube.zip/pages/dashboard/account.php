<header id="page-top" class="bg-light">
	<div class="container text-center">
		<h1>My account</h1>
		<p class="lead">You're currently logged in with <?=$userdata['email'];?> as <?=$userdata['name'];?>.</p>
	</div>
</header>