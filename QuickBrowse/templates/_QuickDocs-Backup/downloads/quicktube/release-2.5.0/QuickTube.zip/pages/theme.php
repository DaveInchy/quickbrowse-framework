<header id="theme" class="bg-light">
	<div class="container text-center">
		<h1>Placeholder</h1>
		<p class="lead">This page is a placeholder.</p>
	</div>
</header>