<header id="welcome" class="bg-light">
	<div class="container text-center">
		<h1 class="font-weight-bold">Welcome to <?=$TEMPLATE->TITLE;?></h1>
		<p class="lead">
			Do you want to try and build your channel into this website?<br>
			It's so smooth you won't even notice.. It's just one click on a button.<br>
			<?=$TEMPLATE->DESCRIPTION;?> version <?=$QUICKBROWSE->VERSION;?>.
		</p>
		<a href="<?=$QUICKBROWSE->DOMAIN;?>/youtube" class="btn btn-outline-primary font-weight-bold">try now!</a>
	</div>
</header>

<section id="music">
	<div class="container">
	  <div class="row">
		<div class="col-lg-8 mx-auto mb-5">
		  <h2 class="text-center">Youtube Music</h2>
		  <p class="lead text-center">You might want to click any video.</p>
		</div>
	  </div>
	  <div class="row">
		<?php
			//Show items from uploads with a limit
			$DISPLAY->uploads_from_playlist($music, $limit);
		?>
	  </div>
	</div>
</section>

<section id="video" class="bg-light">
	<div class="container text-center">
	  <div class="row">
		<div class="col-lg-8 mx-auto mb-5">
		  <h2>Featured Video</h2>
		  <p class="lead">Showing videos on your homepage was never so easy.</p>
		</div>
	  </div>
	  <div class="row">
		<div class="col-lg-8 mx-auto">
			<?php
			//Feature a video
			$DISPLAY->feature_video($TEMPLATE->FEATURED);
			?>
		</div>
	  </div>
	</div>
</section>

<section id="updates">
	<div class="container">
	  <div class="row">
		<div class="col-lg-5 ml-auto">
		  <h2 class="">Updates</h2>
		  <p class="lead">Recent updates that've been uploaded to the blog.</p>
		  <?php
			//Display limited blog posts tagged with 'update'.
			$DISPLAY->blog_posts($POSTS, $USERS, 'update', 2);
		  ?>
		</div>
		<div class="col-lg-3 mr-auto">
		  <?php
			//Include sidebar
			include_once($QUICKBROWSE->TEMPLATE_ROOT . '/includes/blog-sidebar.php');
		  ?>
		</div>
	  </div>
	</div>
</section>

<section id="features" class="bg-light">
	<div class="container">
	  <div class="row">
		<div class="col-md-8 mx-auto">
		  <h2 class="font-weight-bold"><?=$TEMPLATE->TITLE;?>'s features</h2>
		  <p class="lead"><?=$TEMPLATE->TITLE;?> version <span class="font-weight-bold"><?=$TEMPLATE->VERSION;?></span>.
		  <br>Running on QuickBrowse version <span class="font-weight-bold"><?=$QUICKBROWSE->VERSION;?></span>.</p>
		  <ul>
			<li>Easy to use Youtube settings so you can customize your website for your own Youtube Channel.</li>
			<li>Custom dashboard to manage your website's content.</li>
			<li>
				Bootstrap 4 for your website's front-end development.
				<br>With minimal custom CSS so you are free to explore your own unique design options.
			</li>
			<li>
				Every Bootswatch theme integrated into <?=$TEMPLATE->TITLE;?>, so you can free-ly choose what you wan't to look at browsing this website.
			</li>
			<li>
				<?=$TEMPLATE->TITLE;?> is for QuickBrowse version <?=$QUICKBROWSE->VERSION;?>.
				<br>To make sure everything runs optimal as possible and give you as much possible flexibility when it comes to back-end coding for your website.
			</li>
		  </ul>
		</div>
	  </div>
	</div>
</section>

<section id="download">
	<div class="container">
	  <div class="row">
		<div class="col-md-8 mx-auto">
		  <?php
			//Include sidebar
			include_once($QUICKBROWSE->TEMPLATE_ROOT . '/includes/download-section.php');
		  ?>
		</div>
	  </div>
	</div>
</section>