<header id="download-message" class="bg-light">
	<div class="container text-center">
		<div class="col-lg-8 mx-auto">
			<h1><?=$message;?></h1>
			<p class="text-danger"><?=$error;?></p>
			<p class="lead">Please report problems at <a href="<?=$QUICKBROWSE->DOMAIN;?>/contact"><?=$QUICKBROWSE->DOMAIN;?>/contact</a>.<br>If you can't aquire the required files from this website, try to contact <a href="<?=$TEMPLATE->AUTHOR_URL;?>"><?=$TEMPLATE->AUTHOR_EMAIL;?></a>.</p>
		</div>
	</div>
</header>

<section id="download">
	<div class="container">
	  <div class="row">
		<div class="col-md-8 mx-auto">
		  <?php
			//Include sidebar
			include_once($QUICKBROWSE->TEMPLATE_ROOT . '/includes/download-section.php');
		  ?>
		</div>
	  </div>
	</div>
</section>