<section id="blog">
	<div class="container">
		<div class="row">
			<div class="col-lg-5 ml-auto">
				<h2 class="">Blog</h2>
				<p class="lead">A list of all recent blog posts and updates.</p>
				
				<?php
				//Display limited blog posts, should work with index offset
				$DISPLAY->blog_posts($posts, $USERS, "", $args['LIMIT']);
				?>
				
				
				<nav id="page-bottom">
				  <ul class="pagination px-0 px-auto mx-auto">
					<li class="page-item <?php if($CURRENT_INDEX <= 0){ echo 'disabled'; }?>">
					  <a class="page-link border-secondary" href="<?=$QUICKBROWSE->DOMAIN;?>/blog?ind=<?=$CURRENT_INDEX - 1;?>#page-bottom">Back</a>
					</li>
					<?php
					$count = 0;
					foreach($POSTS as $post){
						$count++;
					}
					//set index limit based on how many posts there are
					$HARD_INDEX_LIMIT = $INDEX_LIMIT;
					$INDEX_LIMIT = $count / $args['LIMIT'];
					//check if there are not to many pages, hard limit from old $INDEX_LIMIT = 10?
					if($INDEX_LIMIT > $HARD_INDEX_LIMIT){
						$INDEX_LIMIT = $HARD_INDEX_LIMIT;
					}
					for($i = 0; $i <= $INDEX_LIMIT; $i++){
						$active = false;
						if($i == $CURRENT_INDEX){
							$active = true;
						}
						?>
						<li class="page-item <?php if($active){ echo 'active'; } ?>">
							<a class="page-link border-secondary" href="<?=$QUICKBROWSE->DOMAIN;?>/blog?ind=<?=$i;?>#page-bottom"><?=$i+1;?></a>
						</li>
						<?php
					}
					?>
					<li class="page-item <?php if($CURRENT_INDEX >= $INDEX_LIMIT){ echo 'disabled'; }?>">
					  <a class="page-link border-secondary" href="<?=$QUICKBROWSE->DOMAIN;?>/blog?ind=<?=$CURRENT_INDEX + 1;?>#page-bottom">Next</a>
					</li>
				  </ul>
				</nav>
				
				
			</div>
			<div class="col-lg-3 mr-auto">
			<?php
			//Include sidebar
			include_once($QUICKBROWSE->TEMPLATE_ROOT . '/includes/blog-sidebar.php');
			?>
			</div>
		</div>
	</div>
</section>