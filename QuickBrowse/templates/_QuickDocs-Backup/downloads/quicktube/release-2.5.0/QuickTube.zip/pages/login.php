<section id="login">
	<div style="padding-top: 125px; padding-bottom: 100px;" class="container">
	  <div class="col-xs-12">
		<center>
		  <div class="col-md-4 col-sm-12 jumbotron bg-light text-dark">
			<h1 class="text-uppercase">sign in</h1>
			<p style="color: red;"><?=$error;?></p>
			<form method="POST">

			  <div class="form-group">
				<input class="form-control" type="email" name="form_email" placeholder="Email"></input>
			  </div>
			  <div class="form-group">
				<input class="form-control" type="password" name="form_password" placeholder="Password"></input>
			  </div>

			  <button class="btn btn-block btn-outline-primary" name="btn_login">Log in</button>
			</div>
		  </div>
		</center>
	  </div>
	</div>
</section>