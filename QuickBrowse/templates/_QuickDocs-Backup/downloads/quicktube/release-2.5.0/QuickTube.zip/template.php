<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title><?=$TEMPLATE->TITLE;?> <?=$TEMPLATE->VERSION;?> by <?=$TEMPLATE->AUTHOR;?> - <?=ucfirst($PAGE->get_page_name());?></title>

  <!-- Bootstrap core CSS -->
  <link href="<?=$QUICKBROWSE->FRONTEND_ROOT;?>/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  
  <!-- Bootswatch Theme CSS -->
  <link href="<?=$QUICKBROWSE->FRONTEND_ROOT;?>/assets/css/bootswatch-themes/<?=$THEME;?>.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="<?=$QUICKBROWSE->FRONTEND_ROOT;?>/assets/css/font-awesome.min.css" rel="stylesheet">
  <link href="<?=$QUICKBROWSE->FRONTEND_ROOT;?>/assets/css/scrolling-nav.css" rel="stylesheet">
  <link href="<?=$QUICKBROWSE->FRONTEND_ROOT;?>/assets/css/addons/datatables.min.css" rel="stylesheet">
  <link href="<?=$QUICKBROWSE->FRONTEND_ROOT;?>/assets/css/addons/quill.snow.css" rel="stylesheet">
  <link href="<?=$QUICKBROWSE->FRONTEND_ROOT;?>/assets/css/style.css" rel="stylesheet">

</head>

<body id="page-top" style="min-height: 100vh;">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top" id="mainNav">
    <div class="container">
	  <a class="navbar-brand js-scroll-trigger ml-0" href="<?=$QUICKBROWSE->DOMAIN;?>/home"><?=$TEMPLATE->TITLE;?></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
		<ul class="navbar-nav ml-0">
			<li class="nav-item">
				<a class="nav-link" href="<?=$QUICKBROWSE->DOMAIN;?>/home">Home</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="<?=$QUICKBROWSE->DOMAIN;?>/youtube/">Youtube</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="<?=$QUICKBROWSE->DOMAIN;?>/blog/">Blog</a>
			</li>
        </ul>
		<ul class="navbar-nav ml-1">
		<?php
			$nav = $QUICKBROWSE->TEMPLATE_ROOT . '/includes/nav/' . $PAGE->get_page_file();
			if(file_exists($nav)){
				include_once($nav);
			}
		?>
		</ul>
		<ul class="navbar-nav ml-auto">
		<?php
			if(!$USER->is_logged_in()){
				?>
				<li class="nav-item">
					<a class="nav-link" href="<?=$QUICKBROWSE->DOMAIN;?>/signin">Sign in</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="<?=$QUICKBROWSE->DOMAIN;?>/signup">Sign up</a>
				</li>
				<?php
			}else{
				?>
				<li class="nav-item">
					<a class="nav-link" href="<?=$QUICKBROWSE->DOMAIN;?>/logout">Logout</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="<?=$QUICKBROWSE->DOMAIN;?>/dashboard/index">Dashboard</a>
				</li>
				<?php
			}
		?>
		</ul>
      </div>
    </div>
  </nav>

  <?php
	//Include active page, if it doesn't exist load the error page.
	$header 	= $QUICKBROWSE->TEMPLATE_ROOT . '/headers/' . $PAGE->get_page_file();
	$page 		= $QUICKBROWSE->TEMPLATE_ROOT . '/pages/' . $PAGE->get_page_file();
	if(!file_exists($page)){
		include_once($QUICKBROWSE->TEMPLATE_ROOT . '/headers/error.php');
		include_once($QUICKBROWSE->TEMPLATE_ROOT . '/pages/error.php');
	}else{
		//Include page headers, php scripts
		if(file_exists($header)){
			include_once($header);
		}
		include_once($page);
	}
  ?>

  <!-- Footer -->
  <footer class="py-5 bg-primary text-light">
    <div class="container">
		<div class="row">
			<div class="col-12 col-lg-3">
				<a href="#page-top" class="js-scroll-trigger"><p class="my-4 my-lg-0 text-center text-lg-left text-light text-uppercase" style="font-size: 1.75rem;"><i class="far fa-caret-square-up"></i> Go up</p></a>
			</div>
			<div class="col-12 col-lg-6">
				<p class="m-0 text-center">Copyright &copy; <a class="text-light" href="<?=$QUICKBROWSE->DOMAIN;?>"><?=$TEMPLATE->AUTHOR;?></a>.
				<br>Running on QuickBrowse <?=$QUICKBROWSE->VERSION;?>.</p>
			</div>
			<div class="col-12 col-lg-3">
				<p tabindex="0" data-container="body" data-toggle="popover" data-trigger="focus" data-placement="top" data-html="true" data-title="Choose a Theme" data-content="<?=$DISPLAY->list_group_themes($THEMES, $THEME);?>" class="my-4 my-lg-0 text-center text-lg-right text-light text-uppercase" style="font-size: 1.75rem;">Bootswatch <i class="fas fa-brush"></i></p>
			</div>
		</div>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="<?=$QUICKBROWSE->FRONTEND_ROOT;?>/assets/jquery/jquery.min.js"></script>
  <script src="<?=$QUICKBROWSE->FRONTEND_ROOT;?>/assets/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="<?=$QUICKBROWSE->FRONTEND_ROOT;?>/assets/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom JavaScript for this theme -->
  <script src="<?=$QUICKBROWSE->FRONTEND_ROOT;?>/assets/js/scrolling-nav.js"></script>
  <script src="<?=$QUICKBROWSE->FRONTEND_ROOT;?>/assets/js/addons/datatables.min.js"></script>
  <script src="<?=$QUICKBROWSE->FRONTEND_ROOT;?>/assets/js/addons/quill.min.js"></script>
  <script src="<?=$QUICKBROWSE->FRONTEND_ROOT;?>/assets/js/script.js"></script>

</body>

</html>
