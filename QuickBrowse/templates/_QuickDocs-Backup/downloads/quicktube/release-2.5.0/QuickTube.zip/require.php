<?php

//LOAD INCLUDED CLASSES FROM QUICKBROWSE

	//INITIALIZE PHPMAILER AUTOLOADER
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\Exception;
	require_once($QUICKBROWSE->ROOT . '/php/handler/mail/autoload.php');

	//INITIALIZE YOUTUBE HANDLER
	require_once($QUICKBROWSE->ROOT . '/php/handler/youtube.class.php');
	$YOUTUBE = new Youtube($TEMPLATE->APIKEY);

	//INITIALIZE USER HANDLER
	require_once($QUICKBROWSE->ROOT . '/php/handler/user.class.php');
	$USER = new User();

//LOAD CUSTOM TEMPLATE CLASSES

	//INITIALIZE FUNCTIONS
	require_once($QUICKBROWSE->TEMPLATE_ROOT . '/php/functions.class.php');
	$FUNCTIONS = new Functions();
	
	//EXTEND FUNCTIONS WITH DISPLAY
	require_once($QUICKBROWSE->TEMPLATE_ROOT . '/php/display.class.php');
	$DISPLAY = new Display();
	
?>