<?php
//Include the dashboard dropdown
include_once($QUICKBROWSE->TEMPLATE_ROOT . '/headers/dashboard/blog.php');

if(isset($_GET['action'])){
	$action = $_GET['action'];
	$id = $PAGE->get_content_id();
	switch($action){
		case 'yes':
			if(!$DATA->data_delete('posts', $id)){
				$PAGE->redirect('/theme/error/' . str_replace(' ', '-', $DATA->ERROR));
			}
			$PAGE->redirect('/dashboard/blog/index');
		break;
		
		case 'no':
			$PAGE->redirect('/dashboard/blog/index');
		break;
		
		default:
			$PAGE->redirect('/dashboard/blog/index');
		break;
	}
}
?>