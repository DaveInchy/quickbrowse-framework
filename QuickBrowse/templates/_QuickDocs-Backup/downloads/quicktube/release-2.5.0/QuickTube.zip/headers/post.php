<?php
//Check for url params, if they're present continue the postdata construction
function get_postdata($pid){
	global $POSTS;
	global $USERS;
	$found = false;
	foreach($POSTS as $post){
		if($pid == $post['id']){
			$found = true;
			$data['id'] = $post['id'];
			$data['title'] = $post['title'];
			$data['timestamp'] = $post['timestamp'];
			$data['thumbnail'] = $post['thumbnail'];
			$data['author'] = $post['author'];
			$data['content'] = $post['content'];
			$data['date'] = date('F jS, Y', $post['timestamp']);
			foreach($USERS as $user){
				if($post['author'] == $user['id']){
					$data['author_name'] = $user['name'];
					break;
				}
			}
		}
	}
	if(!$found){
		return false;
	}
	return $data;
}
if(isset($_GET['pid']) && !empty($_GET['pid'])){
	$postid = $_GET['pid'];
	$postdata = get_postdata($postid);
}
if(!empty($PAGE->get_content_id())){
	$postid = $PAGE->get_content_id();
	$postdata = get_postdata($postid);
}
if(!$postdata || !isset($postid)){
	header('Location: ' . $QUICKBROWSE->DOMAIN . '/blog/error/' . $postid . '-not-found');
	exit;
}
?>