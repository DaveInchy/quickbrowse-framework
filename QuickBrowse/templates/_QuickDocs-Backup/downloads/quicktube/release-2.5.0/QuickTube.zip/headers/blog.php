<?php
//Pagination data
$INDEX_LIMIT 	= '10';
$CURRENT_INDEX 	= '0';
//Check if index is set within the url.
if(isset($_GET['ind']) && !empty($_GET['ind']) || $_GET['ind'] >= 0){
	$CURRENT_INDEX = $_GET['ind'];
}

//Setup DATA arguments.
$args['TYPE']	= 'DATA_NEWEST_OFFSET';
$args['LIMIT']	= '2';
$args['OFFSET']	= $CURRENT_INDEX * $args['LIMIT'];

//If OFFSET is 0, please use DATA_NEWEST_LIMIT without the OFFSET argument
if($args['OFFSET'] <= 0){
	$args['TYPE'] = 'DATA_NEWEST_LIMIT';
}

//Call DATA with arguments
$posts = $DATA->data_read('posts', $args);
?>