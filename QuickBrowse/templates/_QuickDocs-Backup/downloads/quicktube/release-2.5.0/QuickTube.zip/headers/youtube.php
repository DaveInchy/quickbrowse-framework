<?php
//Request YOUTUBE uploads.
$limit 			= 8;
$disney 		= $YOUTUBE->get_raw_data('uploads', 'PL4BrNFx1j7E6a6IKg8N0IgnkoamHlCHWa', $limit);
$memes 			= $YOUTUBE->get_raw_data('uploads', 'PLv3TTBr1W_9tppikBxAE_G6qjWdBljBHJ', $limit);
$nightshow 		= $YOUTUBE->get_raw_data('uploads', 'RDOqkPildxhFw', $limit);

//----------Header Form Handler START----------\\
$error = '';
$info = '';
$isset = false;
$request_limit = $limit;
$uploads = Array();

function save_sessions(){
	global $YOUTUBE;
	$data = $YOUTUBE->get_raw_data('channel', $_SESSION['channel']['id']);
	if(isset($data) && $data !== Array()){
		//Save stats to channel session
		$_SESSION['channel'] = $data['channel'];
		$_SESSION['channel']['stats'] = $data['stats'];
		$_SESSION['channel']['content'] = $data['content'];
		$info = "Saved channel data to your session.";
		return true;
	}else{
		$error = "Request went successful but data is empty.";
	}
	return false;
}

if(isset($_POST['submit-channel'])){
	//Set empty multi-dimensional session with prefix "channel".
	$_SESSION['channel'] = Array();
	
	//Check if channel-id is given within the form.
	if(isset($_POST['channel-id']) && !empty($_POST['channel-id'])){
		//Set channel "id" session to channel-id form input
		$_SESSION['channel']['id'] = $_POST['channel-id'];
	}
	
	if(isset($_SESSION['channel']['id']) && !empty($_SESSION['channel']['id'])){
		//Find and save channel information to session.
		if(save_sessions()){
			$info 		= "Saved and found channel id: " . $_SESSION['channel']['id'] . ".";
			$isset 		= true;
			$uploads 	= $YOUTUBE->get_raw_data('uploads', $_SESSION['channel']['content']['relatedPlaylists']['uploads'], $request_limit);
		}else{
			$error = "Couldn't request channel data for id: " . $_SESSION['channel']['id'] . ".";
		}
	}else{
		$error = "Please make sure you filled in a valid \"Channel id\".";
	}
}else{
	//Check if channel session isset
	if(isset($_SESSION['channel']['id']) && !empty($_SESSION['channel']['id'])){
		if(!isset($_SESSION['channel']['title']) || empty($_SESSION['channel']['title'])){
			save_sessions();
		}
		$info 		= "Already found a saved channel id: " . $_SESSION['channel']['id'] . ".";
		$uploads 	= $YOUTUBE->get_raw_data('uploads', $_SESSION['channel']['content']['relatedPlaylists']['uploads'], $request_limit);
		$isset 		= true;
	}//else{
		//if(isset($TEMPLATE->CHANNELID) && !empty($TEMPLATE->CHANNELID)){
			//$_SESSION['channel']['id'] = 'UC-lHJZR3Gqxm24_Vd_AJ5Yw';
			//save_sessions();
			//$info 		= "Set default channel id: " . $_SESSION['channel']['id'] . ".";
			//$uploads 	= $YOUTUBE->get_raw_data('uploads', $_SESSION['channel']['content']['relatedPlaylists']['uploads'], $request_limit);
			//$isset 		= true;
		//}
	//}
}
//----------Header Form Handler END----------\\
?>