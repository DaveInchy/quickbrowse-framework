<?php
$url_data 		= $PAGE->get_subdir_data();
$dir 			= $url_data['dir'];
$path 			= $url_data['path'];
$length 		= $url_data['length'];
$page 			= $dir[0];

$error = 'page ' . $page . ' not found';
if($page != 'error' && $dir[1] == 'error'){
	$error = str_replace('-', ' ', $page);
}
?>