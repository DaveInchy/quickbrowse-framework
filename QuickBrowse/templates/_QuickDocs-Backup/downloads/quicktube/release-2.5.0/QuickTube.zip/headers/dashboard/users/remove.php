<?php
//Include the dashboard dropdown
include_once($QUICKBROWSE->TEMPLATE_ROOT . '/headers/dashboard/users.php');

if(isset($_GET['action'])){
	$action = $_GET['action'];
	$id = $PAGE->get_content_id();
	switch($action){
		case 'yes':
			if(!$DATA->data_delete('users', $id)){
				$PAGE->redirect('/theme/error/' . str_replace(' ', '-', $DATA->ERROR));
			}
			$PAGE->redirect('/dashboard/users/index');
		break;
		
		case 'no':
			$PAGE->redirect('/dashboard/users/index');
		break;
		
		default:
			$PAGE->redirect('/dashboard/users/index');
		break;
	}
}
?>