<?php
if(isset($_GET['set']) && !empty($_GET['set'])){
	$found = false;
	foreach($THEMES as $theme){
		if($_GET['set'] == $theme){
			$found = true;
		}
	}
	if(!$found){
		$PAGE->redirect('/theme/error/theme-' . $_GET['set'] . '-not-found');
	}
	$_SESSION['theme'] = $_GET['set'];
	$PAGE->redirect('/home');
}else{
	$PAGE->redirect('/theme/error/theme-not-set');
}
?>