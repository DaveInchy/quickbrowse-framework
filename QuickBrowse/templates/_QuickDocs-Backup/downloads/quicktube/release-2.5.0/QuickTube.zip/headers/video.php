<?php
//Request YOUTUBE uploads.
$vid = $TEMPLATE->FEATURED;
if(isset($_GET['yid']) && !empty($_GET['yid'])){
	$vid = $_GET['yid'];
}
if(!empty($PAGE->get_content_id())){
	$vid = $PAGE->get_content_id();
}
if(!isset($vid) || $PAGE->get_content_id() == "video"){
	$PAGE->go($QUICKBROWSE->DOMAIN . '/youtube/error/video-not-found');
}
?>