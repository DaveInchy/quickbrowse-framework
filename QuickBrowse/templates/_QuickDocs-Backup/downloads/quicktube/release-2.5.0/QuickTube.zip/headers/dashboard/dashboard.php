<?php
if(!$USER->is_logged_in()){
	//Send to login page. user is not logged in.
	header('Location: ' . $QUICKBROWSE->DOMAIN . '/signin');
	exit();
}

//Set userdata for the one logged in.
if($USER->is_logged_in() && (!isset($userdata) || empty($userdata)) ){
	$userdata = Array();
	foreach($USERS as $user){
		if($USER->get_id() == $user['id']){
			$userdata = $user;
		}
	}
}

//DATA Arguments
$args['TYPE'] = 'DATA_NEWEST_LIMIT';
$args['LIMIT'] = '3';
$args['OFFSET'] = '0';

//DATA Requests
$posts = $DATA->data_read('posts', $args);

//Count users and posts
$posts_count = 0;
foreach($DATA->data_read('posts', Array('TYPE' => 'DATA_NEWEST')) as $row){
	$posts_count++;
}
$users_count = 0;
foreach($DATA->data_read('users', Array('TYPE' => 'DATA_NEWEST')) as $row){
	$users_count++;
}

//Request Channel Statistics
$channel = $YOUTUBE->get_raw_data('channel', $TEMPLATE->CHANNELID);
//print_r($channel);
$stats = $channel['stats'];
$video_count = $stats['videoCount'];
$subscriber_count = $stats['subscriberCount'];
$view_count = $stats['viewCount'];
?>