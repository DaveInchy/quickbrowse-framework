<?php
//Include the dashboard dropdown
include_once($QUICKBROWSE->TEMPLATE_ROOT . '/headers/dashboard/blog.php');
?>