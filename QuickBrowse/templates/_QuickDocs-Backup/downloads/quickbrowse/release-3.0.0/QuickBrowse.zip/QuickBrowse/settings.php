<?php

//TIP: You can call these values with for example: $QUICKBROWSE->VERSION.
//TIP: Look on https://quickbrowse.doonline.nl for the documentation and how to configure these settings.

class QuickBrowseSettings{
	
	//QuickBrowse Settings. (change only if you know what you're doing)
	public $VERSION			= 'release-3.0.0';
	public $DEBUG			= 'off';
	public $ROOT			= './QuickBrowse';
	public $DOCS			= 'https://quickbrowse.doonline.nl';
	
	//Website Settings.									Examples:
	public $DOMAIN			= 'https://mydomain.com';	// https://mydomain.com
	public $TEMPLATE_NAME	= 'exampleTemplate';		// exampleTemplate
	
	//Database Settings.								Examples:
	public $DB_SERVER 		= '127.0.0.1';				// localhost - 127.0.0.1 - 0.0.0.0 - 192.168.0.10
	public $DB_NAME 		= 'db_quickbrowse';			// db_quickbrowse
	public $DB_USER			= 'root';					// root
	public $DB_PASSWORD		= 'admin123';				// admin123
	
	//Dynamic Settings. (not configurable but you can call and set $QUICKBROWSE->TEMPLATE_ROOT)
	public $TEMPLATE_ROOT;
	public $FRONTEND_ROOT;

}
	
?>