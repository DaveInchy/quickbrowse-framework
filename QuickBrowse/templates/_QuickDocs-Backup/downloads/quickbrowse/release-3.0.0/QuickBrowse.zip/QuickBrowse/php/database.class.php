<?php

//------------------------\\//------------------------------------------------\\//------------------------------------------------\\//------------------------\\
// Author: 		DoOnline
// Contact: 	contact@doonline.nl
// Version: 	2.0
// Class: 		Database() (database.class.php)
// Required: 	global QUICKBROWSE, global $CONNECTION
// Location:	QuickBrowse PHP Class
//
// Functions: Handling database (Advanced), Please use $DATA to handle the database (Easy).
//  - _construct();						-> Constructing the Database() Object with data from $QUICKBROWSE.
//
//  - connect();	 					-> Returns a connected mysqli Object if successful, Connects the website to the mysql server. Uses data from $QUICKBROWSE.
//
//	- get_database_settings($SETTING)	-> Returns saved database settings, for example: $DATABASE->get_database_settings('DB_SERVER/DB_USER/DB_PASSWORD/$DB_NAME');
//
//	- data_create($TABLE)				-> (CREATE) Returns the $ID from the newly created row.
//
//	- data_fetch($TABLE, $ARGS)			-> (READ) Returns a sorted array to be used in other classes.
//										Example: (This will show the 5 oldest posts)
//										$args = Array(
//											'TYPE' => 'DATA_OLDEST_LIMIT',
//											'LIMIT' => '5',
//											'OFFSET' => '0'
//										);
//										$DATABASE->data_fetch('posts', $args);
//
//	- data_insert($ARRAY, $ID, $TABLE)	-> (UPDATE) Returns true if successfully updated row with $ID
//										Example: (This will update a row from $TABLE with new data)
//										$data = Array(
//											'title' => 'It is midnight',
//											'description' => 'To be exact its 04:26 AM',
//											'author_id' => $USER->get_id()
//										);
//										$DATABASE->data_insert($data, $_GET['pid'], 'posts');
//
//	- data_delete($ID, $TABLE)			-> Returns true if successfully removed $ID from $TABLE.
//
//------------------------\\//------------------------------------------------\\//------------------------------------------------\\//------------------------\\
	
class Database{
	
	public $DEBUG = false;
	public $ERROR = "";
	public $INFO = "";
	
	private $DB_SERVER;
	private $DB_USER;
	private $DB_PASSWORD;
	private $DB_NAME;

	function __construct(){
		
		try{
			
			$this->INFO = "Saving Database Settings.";
			
			$this->DB_USER = $this->get_database_settings('DB_USER');
			$this->DB_PASSWORD = $this->get_database_settings('DB_PASSWORD');
			$this->DB_SERVER = $this->get_database_settings('DB_SERVER');
			$this->DB_NAME = $this->get_database_settings('DB_NAME');
			
			return true;
		
		}catch(Exception $e){
			
			$this->ERROR = 'Constructor failed with error: ' . $e->getMessage();
			return false;
			
		}
		
	}
	
	function get_database_settings($SETTING){
		
		global $QUICKBROWSE;
		
		try{
		
			if(isset($SETTING)){
			
				switch($SETTING){
					
					case 'DB_USER':
						$this->INFO = 'Requesting get_database_settings(DB_USER).';
						return $QUICKBROWSE->DB_USER;
					break;
					
					case 'DB_PASSWORD':
						$this->INFO = 'Requesting get_database_settings(DB_PASSWORD).';
						return $QUICKBROWSE->DB_PASSWORD;
					break;
					
					case 'DB_NAME':
						$this->INFO = 'Requesting get_database_settings(DB_NAME).';
						return $QUICKBROWSE->DB_NAME;
					break;
					
					case 'DB_SERVER':
						$this->INFO = 'Requesting get_database_settings(DB_SERVER).';
						return $QUICKBROWSE->DB_SERVER;
					break;
					
					default:
						$this->ERROR = 'No setting found with the name: ' .  $SETTING . '.\n
							use one of the following: \n
							SETTING = (default/current),\n
							----------------------------\n
							DB_USER = (root/' . $QUICKBROWSE->DB_USER . '),\n 
							DB_PASSWORD = (password/' . $QUICKBROWSE->DB_PASSWORD . '),\n 
							DB_NAME	= (database/' . $QUICKBROWSE->DB_NAME . '),\n 
							DB_SERVER = (localhost/' . $QUICKBROWSE->DB_SERVER . ').\n
							[NOTICE] Make sure you are using CAPITAL letters.';
						return false;
					break;
					
				}
				
			}else{
				
				$this->ERROR = 'Missing first argument, Make sure you use get_database_settings("DB_USER/DB_PASSWORD/DB_NAME/DB_SERVER").';
				return false;
				
			}
		
		}catch(Exception $e){
			
			$this->INFO = 'Oops... This means QuickBrowse should be updated, Contact us.';
			$this->ERROR = 'Caught error in get_database_settings(), Error: ' . $e->getMessage() . '.';
			return false;
			
		}
		
	}
	
	function connect(){
		
		$mysqli = new mysqli($this->get_database_settings('DB_SERVER'), $this->get_database_settings('DB_USER'), $this->get_database_settings('DB_PASSWORD'), $this->get_database_settings('DB_NAME'));
		
		if($mysqli->connect_errno){
			$this->INFO = 'Make sure the database settings are correct.';
		    $this->ERROR = "Connection failed (" . $mysqli->connect_error . ')';
			return false;
		}else{
			$this->INFO = "Connected to Database";
			return $mysqli;
		}
		return false;
		
	}
	
	function data_fetch($TABLE, $ARGS){
		
		global $CONNECTION;
		
		//Check if arguments are passed trough successfully.
		if(isset($TABLE)){
			if(isset($ARGS) && isset($ARGS['TYPE'])){
				//Different data types for requesting and querying the database
				switch($ARGS['TYPE']){
					
					case 'DATA_RANDOM':
						$this->INFO = 'Selecting all rows from ' . $TABLE . ' ordered by RAND().';
						$sql = 'SELECT * FROM ' . $TABLE . ' ORDER BY RAND()';
					break;
					
					case 'DATA_RANDOM_LIMIT':
						if(!isset($ARGS['LIMIT']) || empty($ARGS['LIMIT'])){
							$this->ERROR = 'Could not select ' . $ARGS['LIMIT'] . ' rows from ' . $TABLE . '.';
							return false;
						}
						$this->INFO = 'Selecting ' . $ARGS['LIMIT'] . ' rows from ' . $TABLE . ' ordered by RAND().';
						$sql = 'SELECT * FROM ' . $TABLE . ' ORDER BY RAND() LIMIT ' . $ARGS['LIMIT'] . '';
					break;
					
					case 'DATA_NEWEST':
						$this->INFO = 'Selecting all newest rows from ' . $TABLE . '.';
						$sql = 'SELECT * FROM ' . $TABLE . ' ORDER BY id DESC';
					break;
					
					case 'DATA_OLDEST':
						$this->INFO = 'Selecting all oldest rows from ' . $TABLE . '.';
						$sql = 'SELECT * FROM ' . $TABLE . ' ORDER BY id ASC';
					break;
					
					case 'DATA_NEWEST_LIMIT':
						if(!isset($ARGS['LIMIT']) || empty($ARGS['LIMIT'])){
							$this->ERROR = 'Could not select ' . $ARGS['LIMIT'] . ' newest rows from ' . $TABLE . '.';
							return false;
						}
						$this->INFO = 'Selecting ' . $ARGS['LIMIT'] . ' newest rows from ' . $TABLE . '.';
						$sql = 'SELECT * FROM ' . $TABLE . ' ORDER BY id DESC LIMIT ' . $ARGS['LIMIT'] . '';
					break;
					
					case 'DATA_OLDEST_LIMIT':
						if(!isset($ARGS['LIMIT']) || empty($ARGS['LIMIT'])){
							$this->ERROR = 'Could not select ' . $ARGS['LIMIT'] . ' oldest rows from ' . $TABLE . '.';
							return false;
						}
						$this->INFO = 'Selecting ' . $ARGS['LIMIT'] . ' oldest rows from ' . $TABLE . '.';
						$sql = 'SELECT * FROM ' . $TABLE . ' ORDER BY id ASC LIMIT ' . $ARGS['LIMIT'] . '';
					break;
					
					case 'DATA_NEWEST_OFFSET':
					if(!isset($ARGS['LIMIT']) || empty($ARGS['LIMIT']) || !isset($ARGS['OFFSET']) || empty($ARGS['OFFSET'])){
							$this->ERROR = 'Could not select newest offset rows (' . $ARGS['OFFSET'] . ' to ' . $ARGS['LIMIT'] . ') from ' . $TABLE . '.';
							return false;
						}
						$this->INFO = 'Selecting newest offset rows (' . $ARGS['OFFSET'] . ' to ' . $ARGS['LIMIT'] . ') from ' . $TABLE . '.';
						$sql = 'SELECT * FROM ' . $TABLE . ' ORDER BY id DESC LIMIT ' . $ARGS['LIMIT'] . ' OFFSET ' . $ARGS['OFFSET'] . '';
					break;
					
					case 'DATA_OLDEST_OFFSET':
						if(!isset($ARGS['LIMIT']) || empty($ARGS['LIMIT']) || !isset($ARGS['OFFSET']) || empty($ARGS['OFFSET'])){
							$this->ERROR = 'Could not select oldest offset rows (' . $ARGS['OFFSET'] . ' to ' . $ARGS['LIMIT'] . ') from ' . $TABLE . '.';
							return false;
						}
						$this->INFO = 'Selecting oldest offset rows (' . $ARGS['OFFSET'] . ' to ' . $ARGS['LIMIT'] . ') from ' . $TABLE . '.';
						$sql = 'SELECT * FROM ' . $TABLE . ' ORDER BY id ASC LIMIT ' . $ARGS['LIMIT'] . ' OFFSET ' . $ARGS['OFFSET'] . '';
					break;
					
					//Set a default for if the arguments are invalid, returning and logging errors 
					default:
						$this->ERROR = 'Theres no type argument (ARGUMENTS["TYPE"]) called: ' . $ARGS['TYPE'] . '.\nMake sure you are using capital letters.';
						return false;
					break;
					
				}
			}else{
				//ARGS['TYPE'] was invalid. however we can still fetch all the data from table.
				$this->ERROR = "Second argurment invalid in fetch( table, arguments ). Make sure to use " . '$args["TYPE"] = "DATA_RANDOM"; as an example.' . " Make sure you create an array with arguments like: " . '$args["TYPE/LIMIT/OFFSET"] = value' . ".";
				$this->INFO = 'Selecting all newest rows from ' . $TABLE . '.';
				$sql = 'SELECT * FROM ' . $TABLE . ' ORDER BY id DESC';
			}
			
			//Trying to execute the query.
			try{
				
				$this->INFO = 'Started query with: ' . $sql . '.';
				$query = $CONNECTION->query($sql);
				
				//Check if the query came trough. if not, log the errors given
				if(!$query){
					$this->INFO = 'This is not your fault, Contact us so we can repair this build.';
					$this->ERROR = 'Failed doing query: ('. $sql . ") --> MYSQL ERROR: " . mysqli_error($CONNECTION) . "";
					return false;
				}else{
					
					while($data = $query->fetch_array()){
						$ARRAY[] = $data;
					}
					$this->INFO = 'Finished query: (' . $sql . ')';
					
					if(!isset($ARRAY) || empty($ARRAY)){
						$this->ERROR = 'Query result is empty, something still went wrong...';
						return false;
					}
					
					//Success! Return all data to the Data Object.
					return $ARRAY;
					
				}
				
			}catch(Exception $e){
				//Catch exceptions and log them
				$this->ERROR = 'Caught exception: ' . $e->getMessage() . '.';
				return false;
			}
		}else{
			//Table not given, canceling
			$this->ERROR = "Missing first argurment table in fetch( table = 'posts', arguments = Array('TYPE' => 'DATA_NEWEST', 'LIMIT' => '0', 'OFFSET' => '0') )";
			return false;
		}
		return false;
	}
	
	function data_create($TABLE){
		
		global $CONNECTION;
		global $DATA;
		
		//Add record on the end of the database.
		$sql = "INSERT INTO " . $TABLE . " () VALUES()";
		$CONNECTION->query($sql);
		$ARGS['TYPE'] = 'DATA_OLDEST';
		$data = $DATA->data_read($TABLE, $ARGS);

		//Go trough all rows and select the latest one, the one on the end of the database.
		foreach($data as $row){
			$id = $row['id'];
		}
		return $id;
		
	}
	
	function data_insert($ARRAY, $ID, $TABLE){
		
		global $CONNECTION;
		
		//Loop trough all data to make sure its the right row who gets updated.
		$keys = array_keys($ARRAY);
		foreach($keys as $key){
			
			$column_name = $key;
			$input = $ARRAY[$key];
			
			$sql = 'UPDATE ' . $TABLE . ' SET ' . $column_name . ' = "' . mysqli_real_escape_string($CONNECTION, $input) . '" WHERE id = "' . $ID . '"; ';
			
			//Query update for column
			if (!$CONNECTION->query($sql)) {
			    $this->ERROR = 'Failed to query update for: ' . $ID . '.<br>' . $CONNECTION->error . '.';
				return false;
			}else{
				$this->INFO = 'Successfully updated ' . $column_name . ' for: ' . $ID;
			}
			
		}
		return true;
	
	}
	
	function data_delete($ID, $TABLE){
		
		global $CONNECTION;
		
		$sql = 'DELETE FROM ' . $TABLE . ' WHERE id = ' . $ID;
		
		//Query delete from database by id.
		if(!$CONNECTION->query($sql)) {
		    $this->ERROR = 'Failed to query update for: ' . $ID . '.\n' . $CONNECTION->error . '';
			return false;
		}
		
		return true;
		
	}

}
	
?>