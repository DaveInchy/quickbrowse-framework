<?php

//------------------------\\//------------------------------------------------\\//------------------------------------------------\\//------------------------\\
// Author: 		DoOnline
// Contact: 	contact@doonline.nl
// Version: 	1.1
// Class: 		User() (user.class.php)
// Required: 	global $DATA, global $QUICKBROWSE
// Location:	QuickBrowse Handlers
//
// Functions: User Handling and user-based functions.
//  - get_id();						-> Returns current logged in user id, returns false if user is not logged in.
//
//	- login($EMAIL, $PASSWORD)		-> Checks 'users' table for a valid match. Returns true if login was valid and matched a saved user in the database.
//
//	- logout()						-> Returns true if logout was successfull.
//
//	- is_logged_in()				-> Returns true if user is logged in and has values saved in this session.
//
// Database: Make sure your database has at least the specified columns and table name.
// Table name: users
// Table columns:
//  - id
//  - email
//  - password
//
//------------------------\\//------------------------------------------------\\//------------------------------------------------\\//------------------------\\

class User{
	
	public $DEBUG = false;
	public $ERROR = '';
	public $INFO = '';
	
	function get_id(){
		if($this->is_logged_in()){
			return $_SESSION['user_id'];
		}
		return false;
	}	

	function login($EMAIL, $PASSWORD){
		global $DATA;
		global $QUICKBROWSE;

		$users = $DATA->data_read('users', Array('TYPE' => 'DATA_NEWEST'));
		$found = false;
		foreach($users as $user){
			if($user['email'] == $EMAIL && $user['password'] == $PASSWORD){
				$_SESSION['user_loggedIn'] = true;
				$_SESSION['user_id'] = $user['id'];
				$found = true;
			}
		}
		if($found){
			return true;
		}else{
			$this->ERROR = 'Wrong credentials, make sure you have signed up at <a href="' . $QUICKBROWSE->DOMAIN . '/signup">' . $QUICKBROWSE->DOMAIN . '/signup</a>.';
			return false;
		}
		return false;
	}

	function logout(){
		if($this->is_logged_in()){
			$_SESSION['user_loggedIn'] = false;
			return true;
		}
		return false;
	}

	function is_logged_in(){
		if(isset($_SESSION['user_loggedIn'])){
			if($_SESSION['user_loggedIn'] == true){
				return true;
			}
		}
		return false;
	}
}
?>
