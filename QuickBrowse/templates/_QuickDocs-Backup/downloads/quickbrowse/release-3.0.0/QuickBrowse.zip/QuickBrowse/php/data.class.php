<?php

//------------------------\\//------------------------------------------------\\//------------------------------------------------\\//------------------------\\
// Author: 		DoOnline
// Contact: 	contact@doonline.nl
// Version: 	2.0
// Class: 		Data() (data.class.php)
// Required: 	global $DATABASE
// Location:	QuickBrowse PHP Class
//
// Functions: Create Read Update Delete (CRUD).
//  - data_create	($ARRAY, $TABLE); 		-> Create a new row in the database and add data to it with $ARRAY, make sure the columns match the array like:
//											Array('column' => $value) or $ARRAY['column'] = $value.
//
//  - data_read		($TABLE, $ARGS); 		-> Returns sorted array of rows from $TABLE. Make sure you fill in both arguments.
//											You can use the $ARGS to request different types of data.
//											The following code makes it so you get the last 10 added records:
//											ARGS['TYPE'] = 'DATA_NEWEST_LIMIT';
//											ARGS['LIMIT'] = '10';
//											ARGS['OFFSET'] = '0';
//
//  - data_update	($ARRAY, $TABLE, $ID); 	-> Updates the selected row from $TABLE sorted by $ID.
//
//  - data_delete	($TABLE, $ID); 			-> Deletes the selected row from $TABLE sorted by $ID.
//
//
// Data types: data_read($TABLE, $ARGS).
//  - DATA_RANDOM			$args = Array('TYPE' => 'DATA_RANDOM', 'LIMIT' => '0', 'OFFSET' => '0');
//  - DATA_RANDOM_LIMIT		$args = Array('TYPE' => 'DATA_RANDOM_LIMIT', 'LIMIT' => '10', 'OFFSET' => '0');
//
//  - DATA_NEWEST			$args = Array('TYPE' => 'DATA_NEWEST', 'LIMIT' => '0', 'OFFSET' => '0');
//  - DATA_OLDEST			$args = Array('TYPE' => 'DATA_OLDEST', 'LIMIT' => '0', 'OFFSET' => '0');
//
//  - DATA_NEWEST_LIMIT		$args = Array('TYPE' => 'DATA_NEWEST_LIMIT', 'LIMIT' => '10', 'OFFSET' => '0');
//  - DATA_OLDEST_LIMIT		$args = Array('TYPE' => 'DATA_OLDEST_LIMIT', 'LIMIT' => '10', 'OFFSET' => '0');
//
//  - DATA_NEWEST_OFFSET	$args = Array('TYPE' => 'DATA_NEWEST_OFFSET', 'LIMIT' => '20', 'OFFSET' => '10');
//  - DATA_OLDEST_OFFSET	$args = Array('TYPE' => 'DATA_OLDEST_OFFSET', 'LIMIT' => '20', 'OFFSET' => '10');
//
//------------------------\\//------------------------------------------------\\//------------------------------------------------\\//------------------------\\

class Data{
	
	public $DEBUG = false;
	public $ERROR = '';
	public $INFO = '';
	
	function data_create($ARRAY, $TABLE){
		
		global $DATABASE;
		
		//Create a record in database without info
		$id = $DATABASE->data_create($TABLE);
		if(!$id){
			$this->ERROR = 'Failed to execute $DATABASE->data_create() function and get $id.';
			return false;
		}
		
		//Insert new data into $id ($id returns the id from the newly created record.)
		if(!$DATABASE->data_insert($ARRAY, $id, $TABLE)){
			$this->ERROR = 'Failed to execute $this->data_create() function.';
			$this->ERROR = $this->ERROR . "<br>" . $DATABASE->ERROR;
			return false;
		}
		return $id;

	}
	
	function data_read($TABLE, $ARGS){
		
		global $DATABASE;
		
		if(!isset($ARGS)){
			$ARGS['TYPE'] = 'DATA_NEWEST';
		}	
		
		//Fetch data and pass trough
		$data = $DATABASE->data_fetch($TABLE, $ARGS);
		if(!$data){
			$this->ERROR = $DATABASE->ERROR;
		}else{
			return $data;
		}
		return false;
		
	}
	
	function data_update($ARRAY, $TABLE, $ID){
		
		global $DATABASE;
		
		//Insert the $ARRAY into a row by id.
		if(!$DATABASE->data_insert($ARRAY, $ID, $TABLE)){
			$this->ERROR = 'Failed to execute data_update() function.';
			$this->ERROR = $this->ERROR . "<br>" . $DATABASE->ERROR;
			return false;
		}
		return true;
		
	}
	
	function data_delete($TABLE, $ID){
		
		global $DATABASE;
		
		//Remove data from table
		if(!$DATABASE->data_delete($ID, $TABLE)){
			$this->ERROR = 'Failed to execute data_delete() function.';
			return false;
		}
		return true;
		
	}
	
}
	
?>