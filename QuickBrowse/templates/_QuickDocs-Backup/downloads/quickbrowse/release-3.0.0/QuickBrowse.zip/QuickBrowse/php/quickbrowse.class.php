<?php

class QuickBrowse extends QuickBrowseSettings{
	
	public $ERROR = '';
	public $INFO = '';
	
	function __construct(){
		try{
			//SETTING MORE SETTINGS
			$this->INFO = $this->INFO . "\n Loading dynamic settings.";
			if(!$this->set_dynamic_settings()){
				$this->ERROR = $this->ERROR . "\n Couldn't set dynamic settings.";
				return false;
			}
			
			//CHECKING QUICKBROWSE FILE STRUCTURES
			$this->INFO = $this->INFO . "\n Loading QuickBrowse and checking program structure.";
			if(!$this->check_quickbrowse_structure()){
				$this->ERROR = $this->ERROR . "\n Couldn't load QuickBrowse.";
				return false;
			}
			
			//CHECKING TEMPLATE FILE STRUCTURES
			$this->INFO = $this->INFO . "\n Loading template (" . $this->TEMPLATE_NAME . ") and checking program structure.";
			if(!$this->check_template_structure()){
				$this->ERROR = $this->ERROR . "\n Couldn't load template (" . $this->TEMPLATE_NAME . ").";
				return false;
			}
			
			//SET PHP ERROR REPORTING
			$this->INFO = $this->INFO . "\n Setting php error reporting to " . $this->DEBUG . ".";
			if(!$this->set_php_errors()){
				$this->ERROR = $this->ERROR . "\n Something went wrong trying to set error reporting to " . $this->DEBUG . ".";
				return false;
			}
		}catch(Exceptions $e){
			//CATCH EXCEPTIONS
			$this->ERROR = $this->ERROR . "\n Exception caught: " . $e->getMessage() . ".";
			return false;
		}
		return true;
	}
	
	private function check_quickbrowse_structure(){
		$dir = "/php/";
		$files = Array(
			"database.class.php",
			"data.class.php",
			"page.class.php"
		);
		foreach($files as $file){
			if(!file_exists($this->ROOT . $dir . $file)){
				$this->ERROR = $this->ERROR . "\n Couldn't find class (" . $file . ") in directory (" . $this->ROOT . $dir . ").";
				return false;
			}
		}
		return true;
	}
	
	private function check_template_structure(){
		$files = Array(
			"template.php",
			"header.php",
			"settings.php"
		);
		foreach($files as $file){
			if(!file_exists($this->TEMPLATE_ROOT . '/' . $file)){
				$this->ERROR = $this->ERROR . "\n Couldn't find " . $file . " in directory (" . $this->TEMPLATE_ROOT . ").";
				return false;
			}
		}
		return true;
	}
	
	private function set_php_errors(){
		ini_set('error_reporting', E_ALL & ~E_NOTICE);
		ini_set('display_errors', $this->DEBUG);
		return true;
	}
	
	private function set_dynamic_settings(){
		$this->TEMPLATE_ROOT = $this->ROOT . '/templates/' . $this->TEMPLATE_NAME;
		$this->FRONTEND_ROOT = $this->ROOT . '/templates/' . $this->TEMPLATE_NAME;
		return true;
	}
	
}

?>