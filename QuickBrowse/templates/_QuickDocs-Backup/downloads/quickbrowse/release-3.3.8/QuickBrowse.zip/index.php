<?php
	
	//QuickBrowse - (https://QuickBrow.se).
	//Copyright 2016-2019 doOnline.nl,
	//Licensed under MIT (LICENSE.TXT).
	//CONTRIBUTORS: D. van Dooijeweert & Diego Ronca.
	//DOCUMENTATION: https://QUICKBROW.SE/DOCS/.
	
	//LOAD QUICKBROWSE
	include_once('./QuickBrowse/quickbrowse.php');
	
?>
