<?php

class QuickBrowse extends QuickBrowseSettings{
	
	//QuickBrowse Messages.
	public $ERROR = '';
	public $INFO = '';
	
	//QuickBrowse Static Settings. 	(Crucial for constructing objects)
	public $ROOT = './QuickBrowse';
	
	//QuickBrowse Dynamic Settings.
	public $TEMPLATE_ROOT;
	public $FRONTEND_ROOT;
	public $ASSETS_URL;
	public $ASSETS_DIR;
	
	//QuickBrowse Components.
	public $ASSETSPACK;
	public $DATABASE;
	public $CRUD;
	public $PAGE;
	public $TEMPLATE;
	
	function __construct($err_notice){
		
		//1.0 SET PHP ERROR REPORTING
		$this->INFO = $this->INFO . "\n Setting php error reporting to " . $this->DEBUG . ".";
		if(!$this->set_php_errors($err_notice)){
			$this->ERROR = $this->ERROR . "\n Something went wrong trying to set error reporting to " . $this->DEBUG . ".";
			return false;
		}
		
		//2.0 SETTING DYNAMIC SETTINGS
		$this->INFO = $this->INFO . "\n Loading dynamic settings.";
		if(!$this->set_dynamic_settings()){
			$this->ERROR = $this->ERROR . "\n Couldn't set dynamic settings.";
			return false;
		}
		
		//3.0 CHECKING QUICKBROWSE FILE STRUCTURE
		$this->INFO = $this->INFO . "\n Loading QuickBrowse and checking program structure.";
		if(!$this->check_quickbrowse_structure()){
			$this->ERROR = $this->ERROR . "\n Couldn't load QuickBrowse.";
			return false;
		}
		
		//3.1 INITIALIZE AND SET QUICKBROWSE COMPONENTS
		$this->INFO = $this->INFO . "\n Loading and setting QuickBrowse components.";
		if(!$this->init_components()){
			$this->ERROR = $this->ERROR . "\n Couldn't load components for QuickBrowse.";
			return false;
		}
		
		//4.0 CHECKING TEMPLATE FILE STRUCTURE
		$this->INFO = $this->INFO . "\n Loading template (" . $this->TEMPLATE_NAME . ") and checking program structure.";
		if(!$this->check_template_structure()){
			$this->ERROR = $this->ERROR . "\n Couldn't load template (" . $this->TEMPLATE_NAME . ").";
			return false;
		}
		
		//4.1 INITIALIZING AND INCLUDING QUICKBROWSE TEMPLATE
		$this->INFO = $this->INFO . "\n Loading template files.";
		if(!$this->init_template()){
			$this->ERROR = $this->ERROR . "\n Couldn't load template (" . $this->TEMPLATE_NAME . ").";
			return false;
		}
		
		return true;
	}
	
	private function set_php_errors($err_notice = false){
		try{
			$err = E_ALL;
			if(!$err_notice){
				$err = E_ALL & ~E_NOTICE;
			}
			ini_set('error_reporting', $err);
			ini_set('display_errors', $this->DEBUG);
		}catch(Exception $e){
			$this->ERROR = $this->ERROR . "\n Caught Exception: " . $e->getMessage() . '.';
			return false;
		}
		return true;
	}
	
	private function set_dynamic_settings(){
		try{
			$QUICKBROWSE_DIR = str_replace('./', '', $this->ROOT);
			$this->ASSETS_URL = $this->DOMAIN . '/' . $QUICKBROWSE_DIR . '/assets/';
			$this->ASSETS_DIR = $this->ROOT . '/assets/';
			$this->TEMPLATE_ROOT	= $this->ROOT . '/templates/' . $this->TEMPLATE_NAME;
			$this->FRONTEND_ROOT	= $this->DOMAIN . '/' . $this->TEMPLATE_ROOT;
		}catch(Exception $e){
			$this->ERROR = $this->ERROR . "\n Caught Exception: " . $e->getMessage() . '.';
			return false;
		}
		return true;
	}
	
	private function check_quickbrowse_structure(){
		$dir = "/php/";
		$files = Array(
			"assetspack.class.php",
			"database.class.php",
			"crud.class.php",
			"page.class.php"
		);
		foreach($files as $file){
			if(!file_exists($this->ROOT . $dir . $file)){
				$this->ERROR = $this->ERROR . "\n Couldn't find class (" . $file . ") in directory (" . $this->ROOT . $dir . ").";
				return false;
			}
		}
		return true;
	}
	
	private function check_template_structure(){
		$files = Array(
			"settings.php",
			"header.php",
			"template.php"
		);
		foreach($files as $file){
			if(!file_exists($this->TEMPLATE_ROOT . '/' . $file)){
				$this->ERROR = $this->ERROR . "\n Couldn't find " . $file . " in directory (" . $this->TEMPLATE_ROOT . ").";
				return false;
			}
		}
		return true;
	}
	
	public function err_check($object){
		if(!empty($object->ERROR)){
			return $object->ERROR;
		}
		return true;
	}
	
	private function init_components(){
		try{
			if($this->LOAD_ASSETS){
				$this->ASSETSPACK = new AssetsPack($this, $this->ASSETS_URL, $this->ASSETS_DIR, $this->USE_CDN);
				$result = $this->err_check($this->ASSETSPACK);
				if(!$result){
					$this->ERROR = $this->ERROR . "\n" . $result;
					return false;
				}
			}
			
			$this->PAGE = new Page($this);
			$result = $this->err_check($this->PAGE);
			if(!$result){
				$this->ERROR = $this->ERROR . "\n" . $result;
				return false;
			}
			
			$this->DATABASE = new Database($this->DB_USER, $this->DB_PASSWORD, $this->DB_SERVER, $this->DB_NAME);
			$result = $this->err_check($this->DATABASE);
			if(!$result){
				$this->ERROR = $this->ERROR . "\n" . $result;
				return false;
			}
			
			$this->CRUD = new CRUD($this->DATABASE);
			$result = $this->err_check($this->CRUD);
			if(!$result){
				$this->ERROR = $this->ERROR . "\n" . $result;
				return false;
			}
			
		}catch(Exception $e){
			$this->ERROR = $this->ERROR . "\n Caught Exception: " . $e->getMessage() . ".";
			return false;
		}
		return true;
	}
	
	private function init_template(){
		try{
			require_once($this->TEMPLATE_ROOT . '/settings.php');
			$this->TEMPLATE = new TemplateSettings();
			
			$QB = $this;
			if(file_exists($this->TEMPLATE_ROOT . '/require.php')){
				include_once($this->TEMPLATE_ROOT . '/require.php');
			}
			
			include_once($this->TEMPLATE_ROOT . '/header.php');
			include_once($this->TEMPLATE_ROOT . '/template.php');
			
		}catch(Exception $e){
			$this->ERROR = $this->ERROR . "\n Caught Exception: " . $e->getMessage() . ".";
			return false;
		}
		return true;
	}
	
}

?>