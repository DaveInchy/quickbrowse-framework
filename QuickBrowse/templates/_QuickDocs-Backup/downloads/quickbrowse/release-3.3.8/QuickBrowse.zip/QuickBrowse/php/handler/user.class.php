<?php

class UserHandler{
	
	public $ERROR = '';
	public $INFO = '';
	
	private $CRUD;
	private $TABLE;
	
	private $DASHBOARD_URL;
	private $REGISTER_URL;
	private $LOGIN_URL;
	
	private $SEED = 'QB_Hz2kdf';
	private $PUBLIC;
	private $PRIVATE;
	
	function __construct($USERS_CRUD, $USERS_TABLE, $REGISTER = "./register", $LOGIN = "./login", $DASHBOARD = "./dashboard", $UNIQUE = '3.3.2:04-09-2019'){
		$this->CRUD = $USERS_CRUD;
		$this->TABLE = $USERS_TABLE;
		
		$this->DASHBOARD_URL = $DASHBOARD;
		$this->REGISTER_URL = $REGISTER;
		$this->LOGIN_URL = $LOGIN;
		
		$this->SEED = sha1($this->SEED . '-' . $UNIQUE);
		return true;
	}
	
	function get_session_data(){
		if($this->is_logged_in()){
			return $_SESSION['quickbrowse_user'];
		}
		return false;
	}
	
	function get_users_data(){
		$data = $this->CRUD->data_read($this->TABLE, Array('TYPE' => 'DATA_NEWEST'));
		return $data;
	}
	
	function get_user_data($id){
		$data = $this->CRUD->data_read($this->TABLE, Array('TYPE' => 'DATA_NEWEST'));
		foreach($data as $user){
			if($id == $user['id']){
				return $user;
			}
		}
		return false;
	}
	
	function encrypt($content){
		if(!isset($content) || empty($content)){
			$this->ERROR = $this->ERROR . "\n ";
			return false;
		}
		$encrypted = md5($SEED . $content);
		return $encrypted;
	}

	function register($FIRST_NAME, $LAST_NAME, $EMAIL, $PASSWORD, $PASSWORD_CONFIRM){
		return false;
	}

	function login($EMAIL, $PASSWORD){
		$users = $this->get_users_data();
		$found = false;
		foreach($users as $user){
			if($user['email'] == $EMAIL && $user['password'] == $PASSWORD){
				$_SESSION['quickbrowse_user_logged'] = true;
				$_SESSION['quickbrowse_user'] = $user;
				return true;
			}
		}
		$this->ERROR = 'Wrong credentials, make sure you have created an account at <a href="' . $this->REGISTER_URL . '">Sign-up</a>.';
		return false;
	}

	function logout(){
		if($this->is_logged_in()){
			$_SESSION['quickbrowse_user_logged'] = false;
			$_SESSION['quickbrowse_user'] = null;
			return true;
		}
		return false;
	}

	function is_logged_in(){
		if(isset($_SESSION['quickbrowse_user_logged'])){
			if($_SESSION['quickbrowse_user_logged'] == true){
				return true;
			}
		}
		return false;
	}
}
?>
