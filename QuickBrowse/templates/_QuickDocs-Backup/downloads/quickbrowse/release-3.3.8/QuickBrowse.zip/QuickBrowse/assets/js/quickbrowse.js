function QBJS(){
	//Object Properties
	this.objectName 	= 'QuickBrowseJS',
	this.version 		= '1.1.0',
	this.enableLogging 	= true,
	
	//Objects 
	this.Log 			= new QB_LOG(this.enableLogging),
	this.API 			= undefined,
	this.CurrentUser 	= undefined,
	
	//Object Constructor or Initializer
	this.Init = (data) => {
		//Check if data is not empty
		if(data !== undefined){
			this.Log.setMessage('success', "Found defined data in data .");
			
			//Checking if url data exists
			if(data.url !== undefined){
				this.Log.setMessage('success', "Found defined url data in data.url .");
			}
			
			//Checking if user data exist
			if(data.user !== undefined){
				this.Log.setMessage('success', "Found data.user.");
				
				//Saving User to the QuickBrowse Object
				var Data = data.user;
				var User = new QB_USER(this.Log);
				if(!User.Init(Data.loggedin, Data.uid, Data.public, Data.name, Data.email, Data.permissions, Data.signature, Data.json)){
					var Error = this.Log.getMessage();
					//Log.setMessage('error', "Couldn't load new QB_USER Object .");
					return false;
				}
				this.CurrentUser = User;
			}
		}
		return true;
	}
	//Object Functions
	this.setAPI = () => {
		if(this.CurrentUser == undefined){
			this.Log.setMessage('error', "Couldn't set API, User for Authentication is undefined.");
			return false;
		}
		if(!this.CurrentUser.Loggedin){
			this.Log.setMessage('error', "Couldn't set API, User needs to be logged in for Authentication.");
			return false;
		}
		return true;
	}
}

function QB_API(log_handler, logged_user){
	//Object Properties
	this.URL = 'https://api.quickbrow.se/v1/',
	
	//Object Functions
	this.Connect
	
}

function QB_LOG(state){
	//Object Properties
	this.Logging = state,
	this.latestMessage = undefined,
	this.MessageType = undefined,
	
	//Object Functions
	this.getMessage = (messageOnly = false) => {
		if(messageOnly){
			return this.latestMessage;
		}
		return '(' + this.MessageType.toUpperCase() + ') ' + this.latestMessage;
	},
	this.setMessage = (type, txt) => {
		this.latestMessage = txt;
		this.MessageType = type;
		if(this.Logging){
			console.log(this.getMessage());
		}
		return true;
	}
}

function QB_USER(log_handler){
	
	//Object Properties
	this.Loggedin = undefined,
	this.Uid = undefined,
	this.Public = undefined,
	this.Name = undefined,
	this.Email = undefined,
	this.Permissions = undefined,
	this.Rank = undefined,
	this.Signature = undefined,
	
	//JS Objects
	this.Log = log_handler,
	
	//Object Constructor or Initializer
	this.Init = (loggedin, uid, public, name, email, permissions, signature, json) => {
		this.Log.setMessage('info', "1. Initializing QB_User with given arguments.");
		this.Loggedin = loggedin;
		this.Log.setMessage('info', "2. Checking if user is logged so we have actual data to work with.");
		if(!this.Loggedin){
			this.Uid 			= 'noUid';
			this.Public 		= 'noAuth';
			this.Name 			= 'noName';
			this.Email 			= 'noEmail';
			this.Permissions 	= 'noPermissions';
			this.Signature 		= 'noSignature';
			this.Json	 		= 'noExtra';
			this.Log.setMessage('error', "Stopped initializing, No logged user so theres no data to work with.");
			this.Log.setMessage('error', "Setting dummy values for properties.");
			return false;	
		}
		this.Uid 			= uid;
		this.Public 		= public;
		this.Name 			= name;
		this.Email 			= email;
		this.Permissions 	= permissions;
		this.Signature 		= signature;
		this.Json	 		= json;
		this.setRank(this.Permissions);
		this.Log.setMessage('success', "3. Finished initializing QB_User with properties.");
		return true;
	},
	
	//Object Functions
	this.setRank = (perms) => {
		this.Log.setMessage('info', "Setting User's rank based on permissions.");
		if(perms == 0){
			this.Rank = 'Banned';
		}
		if(perms == 1){
			this.Rank = 'User';
		}
		if(perms == 2){
			this.Rank = 'Moderator';
		}
		if(perms == 3){
			this.Rank = 'Owner / Administrator';
		}
		this.Log.setMessage('success', "Finished setting User's rank to " + this.Rank + ".");
		return true;
	}
}