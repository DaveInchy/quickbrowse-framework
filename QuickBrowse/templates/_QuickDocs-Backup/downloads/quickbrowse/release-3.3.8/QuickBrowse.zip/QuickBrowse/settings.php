<?php

class QuickBrowseSettings{
	
	//QuickBrowse Settings. (change only if you know what you're doing)
	public $VERSION			= 'released-3.3.8';
	public $DEBUG			= 'off';
	public $DOCS_URL		= 'https://quickbrow.se/docs/';
	
	//API Settings.
	public $API_URL			= 'https://api.quickbrow.se/v1/';
	public $API_KEY			= 'API-0000000000-demo';
	
	//Website Settings.
	public $DOMAIN			= 'https://domain.com';
	public $TEMPLATE_NAME	= 'ExampleTemplate';
	
	//Main Database Settings.
	public $DB_SERVER 		= 'localhost';
	public $DB_NAME 		= 'database';
	public $DB_USER			= 'root';
	public $DB_PASSWORD		= '';
	
	//AssetPack Settings.
	public $LOAD_ASSETS		= true;
	public $USE_CDN			= true;

}
	
?>