<?php

class AssetsPack{

	public $ERROR = '';
	public $INFO = '';
	
	public $ROOT;
	public $ROOT_URL;
	
	private $QUICKBROWSE;
	public $DISPLAY;

	public $CDN_URL = 'https://quickbrow.se/QuickBrowse/assets/';
	
	private $ASSET;
	private $ASSET_LIST = Array
	(
		'css/' => Array
		(
			'responsive.css',
			'utility.css'
		),
		'css/lib/animate/' => Array
		(
			'animate.css'
		),
		'css/lib/bootstrap/' => Array
		(
			'bootstrap.min.css',
			'bootstrap-navbar.css'
		),
		'bootswatch/' => Array
		(
			'bootstrap.css',
			'cerulean.css',
			'cosmo.css',
			'cyborg.css',
			'darkly.css',
			'flatly.css',
			'journal.css',
			'litera.css',
			'lumen.css',
			'lux.css',
			'materia.css',
			'minty.css',
			'pulse.css',
			'sandstone.css',
			'simplex.css',
			'sketchy.css',
			'slate.css',
			'spacelab.css',
			'superhero.css',
			'united.css',
			'yeti.css',
		),
		'js/' => Array
		(
			'quickbrowse.js'
		),
		'js/lib/wowjs/' => Array
		(
			'wow.min.js'
		),
		'js/lib/jquery/' => Array
		(
			'jquery.min.js',
			'jquery-slim.min.js',
			'jquery-easing.min.js'
		),
		'js/lib/bootstrap/' => Array
		(
			'bootstrap.js',
			'bootstrap-navbar.js'
		),
		'img/pattern/' => Array
		(
			'chalkboard.jpg',
			'figures.png',
			
			'stars.svg',
			'stripes.svg',
			'triangles.svg'
		),
		'img/background/' => Array
		(
			'mountains-blue.svg',
			'mountains-dark.svg',
			'mountains-green.svg',
			'mountains-light.svg',
			'mountains-purple.svg',
			'mountains-red.svg',
			'mountains-yellow.svg',
			
			'sharp-gradient-blue.svg',
			'sharp-gradient-dark.svg',
			'sharp-gradient-green.svg',
			'sharp-gradient-light.svg',
			'sharp-gradient-purple.svg',
			'sharp-gradient-red.svg',
			'sharp-gradient-yellow.svg',
			
			'space.svg',
			
			'tile-blue.svg',
			'tile-dark.svg',
			'tile-green.svg',
			'tile-light.svg',
			'tile-purple.svg',
			'tile-red.svg',
			'tile-yellow.svg'
		),
		'img/icon/' => Array
		(
			'favicon.ico',
			'favicon-16.png',
			'favicon-32.png',
			'favicon-96.png',
			'favicon-192.png'
		),
		'img/logo/' => Array
		(
			'logo.png',

			'logo-doonline-sm.png',
			'logo-webbouwerz-sm.png',
			'logo-bootstrap-sm.png',
			'logo-bootswatch-sm.png',

			'logo-bootswatch-lg.png',
			'logo-bootstrap-lg.png',
			'logo-doonline-lg.jpg',
		)
	);

	function __construct($QUICKBROWSE, $ROOT_URL, $ROOT_DIR, $CDN = false){
		try{
			//LOADING ASSETS INTO $QUICKBROWSE->ASSETSPACK->ASSET
			$this->INFO 	= $this->INFO . "\n Constructing and Loading assetspack";
			$this->ROOT_URL = $ROOT_URL;
			$this->ROOT 	= $ROOT_DIR;

			if(!$this->load_assets($CDN)){
				$this->ERROR = $this->ERROR . "\n Something went wrong while Loading assets.";
				return false;
			}

			$this->INFO = $this->INFO . "\n Saving QuickBrowse and Display Objects.";
			$this->QUICKBROWSE = $QUICKBROWSE;
			$this->DISPLAY = new AssetsPackDisplay();
			$this->DISPLAY->QUICKBROWSE = $QUICKBROWSE;

		}catch(Exception $e){
			$this->ERROR = $this->ERROR . "\n Constuctor for assetspack failed: " . $e->getMessage() . ".";
			return false;
		}
		$this->INFO = $this->INFO . "\n Finished Constructing and Loading assetsoack";
		return true;
	}

	private function load_assets($cdn){
		try{
			$this->INFO = $this->INFO . '\n Searching trough assets list for files.';
			foreach($this->ASSET_LIST as $loc => $files){
				foreach($files as $file){
					if(!$this->set_asset($cdn, $loc, $file)){
						$this->ERROR = $this->ERROR . "\n Couldn't set asset: " . $key . $file . '.';
						return false;
					}
				}
			}
		}catch(Exception $e){
			$this->ERROR = $this->ERROR . "\n Caught Exception: " . $e->getMessage() . '.';
			return false;
		}
		return true;
	}

	private function asset_exists($asset){
		$this->INFO = $this->INFO . "\n Checking if asset " . $asset . " exists.";
		if(!isset($this->ASSET[$asset])){
			$this->ERROR = $this->ERROR . "\n No asset found named: " . $asset . ".";
			return false;
		}
		return true;
	}

	private function set_asset($cdn, $location, $file){
		try{
			$this->INFO = $this->INFO . "\n Loading " . $location[0] . $file . " into assetspack.";

			//Format asset into call type. Example: IMG-LOGO, CSS-UTILITY, use print_assets() to get the whole list
			$asset = strstr($file, '.', true);
			$asset = strstr($location, '/', true) . '-' . $asset;
			$asset = strtoupper($asset);

			$cdn_url = $this->CDN_URL . $location . $file;
			$url = $this->ROOT_URL . $location . $file;
			$filepath = $this->ROOT . $location . $file;
			if($cdn == false){
				if(!file_exists($filepath)){
					$this->ERROR = $this->ERROR . "\n Couldn't find filepath: " . $filepath . ".";
					return false;
				}
				$this->ASSET[$asset] = $url;
				$this->INFO = $this->INFO . "\n Saved a valid file to: " . $url . " into assetspack.";
			}else{
				$this->ASSET[$asset] = $cdn_url;
				$this->INFO = $this->INFO . "\n Used cdn as valid file to: " . $url . " into assetspack.";
			}
		}catch(Exception $e){
			$this->ERROR = $this->ERROR . "\n Caught Exception: " . $e->getMessage() . '.';
			return false;
		}
		return true;
	}

	function get_asset($asset){
		$this->INFO = $this->INFO . "\n Trying to return asset " . $asset . ".";
		if(!$this->asset_exists($asset)){
			$this->ERROR = $this->ERROR . "\n Failed to return asset, asset " . $asset . " does not exist.";
			return false;
		}
		return $this->ASSET[$asset];
	}

	function print_assets(){
		?><pre class="bg-chalk text-light"><?php
		$c = 0;
		foreach($this->ASSET as $key => $file){
			$c++;
			$space = '		';
			if(strlen($c) <= 1){
				$c = '0' . $c;
			}
			if(strlen($key) <= 12){
				$space = '	' . $space;
			}
			if(strlen($key) > 20){
				$space = '	';
			}
			?><span class="line" data-line-number="<?=$c;?>">TYPE: <?=$key;?><?=$space;?><?=$file;?></span><br><?php
		}
		?></pre><?php
	}

	function img($asset = 'IMG-LOGO-DOONLINE', $size = '100%'){
		$this->INFO = $this->INFO . "\n Including image element with asset: " . $asset . ".";
		?><img width="<?=$size;?>" class="img-fluid" src="<?=$this->get_asset($asset);?>" alt="<?=$asset;?>"/><?php
	}

	function icon_pack(){
		$this->INFO = $this->INFO . "\n Including QuickBrowse favicons.";
		?>
			<!-- QuickBrowse Package - Icons -->
			<link rel="icon" type="image/png" sizes="192x192" href="<?=$this->get_asset('IMG-FAVICON-192');?>">
			<link rel="icon" type="image/png" sizes="96x96" href="<?=$this->get_asset('IMG-FAVICON-96');?>">
			<link rel="icon" type="image/png" sizes="32x32" href="<?=$this->get_asset('IMG-FAVICON-32');?>">
			<link rel="icon" type="image/png" sizes="16x16" href="<?=$this->get_asset('IMG-FAVICON-16');?>">
		<?php
	}

	function css_pack($THEME = 'none'){
		$this->INFO = $this->INFO . "\n Including QuickBrowse css.";
		$this->bootstrap('css', $THEME);
		?>
		<!-- QuickBrowse Style Package - QuickBrowse CSS -->
		<link type="text/css" href="<?=$this->get_asset('CSS-ANIMATE');?>" rel="stylesheet">
		<link type="text/css" href="<?=$this->get_asset('CSS-RESPONSIVE');?>" rel="stylesheet">
		<link type="text/css" href="<?=$this->get_asset('CSS-UTILITY');?>" rel="stylesheet">
		<?php
	}

	function js_pack($JSON_DATA){
		$this->INFO = $this->INFO . "\n Including QuickBrowse JS.";
		$this->bootstrap('js');
		?>
		<!-- QuickBrowse Javascript Package - QuickBrowse JS -->
		<script type="application/javascript" src="<?=$this->get_asset('JS-QUICKBROWSE');?>"></script>
		<script type="application/javascript">
			var QuickBrowse = new QBJS();
			var JSON = <?=$JSON_DATA;?>;
			QuickBrowse.Init(JSON);
		</script>
		<script type="application/javascript" src="<?=$this->get_asset('JS-WOW');?>"></script>
		<?php
	}

	function meta_pack($title = 'Website build with ease because of https://QuickBrow.se', $description = 'Visit https://QuickBrow.se/get-started for more information.', $author = 'doOnline.nl', $theme_color = '#dc3545'){
		$this->INFO = $this->INFO . "\n Including QuickBrowse Head Metadata.";
		?>
		<!-- QuickBrowse Package - Metadata SEO -->
		<meta charset="utf-8">
		<title><?=$title;?></title>
		<meta name="description" content="<?=$description;?>">
		<meta name="author" content="<?=$author;?>">
		<!-- QuickBrowse Package - Mobile Options -->
		<meta name="theme-color" content="<?=$theme_color;?>">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<?php
	}

	function bootstrap($filetype = 'css', $theme = 'none'){
		$this->INFO = $this->INFO . "\n Including QuickBrowse Bootstrap " . $filetype . ".";
		switch(strtoupper($filetype)){
			case 'CSS':
				?>
					<!-- QuickBrowse Bootstrap Package - Main CSS -->
					<link type="text/css" href="<?=$this->get_asset('CSS-BOOTSTRAP');?>" rel="stylesheet">
					<!-- QuickBrowse Bootstrap Package - Navbar CSS -->
					<link type="text/css" href="<?=$this->get_asset('CSS-BOOTSTRAP-NAVBAR');?>" rel="stylesheet">
				<?php
				if($theme != 'none'){
				?>
					<!-- QuickBrowse Bootstrap Package - Bootswatch CSS -->
					<link type="text/css" href="<?=$this->get_asset(strtoupper($theme));?>" rel="stylesheet">
				<?php
				}
			break;

			case 'JS':
				?>
					<!-- QuickBrowse Bootstrap Package - JQuery JS -->
					<script type="application/javascript" src="<?=$this->get_asset('JS-JQUERY');?>"></script>
					<script type="application/javascript" src="<?=$this->get_asset('JS-JQUERY-EASING');?>"></script>
					<!-- QuickBrowse Bootstrap Package - Main JS -->
					<script type="application/javascript" src="<?=$this->get_asset('JS-BOOTSTRAP');?>"></script>
					<!-- QuickBrowse Bootstrap Package - Navbar JS -->
					<script type="application/javascript" src="<?=$this->get_asset('JS-BOOTSTRAP-NAVBAR');?>"></script>
				<?php
			break;
		}
	}
}

class AssetsPackDisplay{

	public $ERROR = '';
	public $INFO = '';
	
	public $QUICKBROWSE;
	
	public function str_encode_code($code){
		$txt[1] = str_replace('&', '&amp', $code);
		$txt[2] = str_replace('<', '&lt', $txt[1]);
		$txt[3] = str_replace('>', '&gt', $txt[2]);
		$txt[4] = str_replace('$', '&#0036', $txt[3]);
		return $txt[4];
	}
	
	function str_lipsum(){
		return 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam pellentesque velit at vulputate cursus. Mauris vel turpis tortor. Nulla facilisi. Donec augue velit, blandit vitae consequat eu, gravida nec tellus. Donec tempus dui eu venenatis hendrerit. Morbi ac pretium arcu, et faucibus est. Cras congue non ante nec maximus. Nulla venenatis vel ipsum vehicula eleifend. Pellentesque consectetur mollis metus, sed congue enim. Aliquam fermentum neque eu mattis consectetur. Ut bibendum rutrum est eu gravida. Sed non consequat mi. ';
	}
	
	function html_banner($TYPE, $banner_bg = 'bg-gradient-purple'){
		$TEMPLATE = $this->QUICKBROWSE->TEMPLATE;
		try{
			switch($TYPE){
				
				case 'contact':
					?>
					<section id="notify-hire-2" class="<?=$banner_bg;?> py-5">
						<div class="container text-center">
							<h3 class="lead mb-0 text-light">Wan't to hire <a href="<?=$TEMPLATE->AUTHOR_URL;?>" class="text-light"><?=$TEMPLATE->AUTHOR;?></a>? Please send us an email trough <a href="<?=$this->QUICKBROWSE->DOMAIN;?>/about" class="text-light">contact</a>.</h3>
						</div>
					</section>
					<?php
				break;
				
				case 'download':
					?>
					<section id="notify-release" class="<?=$banner_bg;?> py-5">
						<div class="container text-center">
							<h3 class="lead mb-0 font-weight-bold text-light">Create web-applications quick! <a href="https://quickbrow.se/downloads" class="text-dark mx-auto btn btn-md btn-light m-1">Download</a> <span class="text-primary d-none d-md-inline">QuickBrowse</span> <span class="text-danger d-none d-md-inline"><?=$this->QUICKBROWSE->VERSION;?></span></h3>
						</div>
					</section>
					<?php
				break;
				
				default:
					$this->ERROR = $this->ERROR . 'Cant find given type as selector for the types of banners.';
					return false;
				break;
				
			}
		}catch(Exception $e){
			$this->ERROR = $this->ERROR . 'Caught Exception: ' . $e->getMessage();
			return false;
		}
		return;
	}
	
	function html_uploads($handler, $playlist = 'UUVDclw75RsDHumNAaCmXM_w', $limit = 8, $txt_color = 'dark'){
		try{
			$YOUTUBE = $handler;
			$items = $YOUTUBE->get_raw_data('uploads', $playlist, $limit);
			$c = 0;
			foreach($items as $upload){
				$c++;
				if($c <= $limit){
					$uploadId = $upload['snippet']['resourceId']['videoId'];
					$videodata = $YOUTUBE->get_raw_data('video', $uploadId);
					if(!$videodata){
						$this->ERROR = $YOUTUBE->ERROR;
						return false;
					}
					?>
					<div class="col-lg-3 mt-3" style="padding: 5px; padding-top: 0px; padding-bottom: 0px;">
					  <a class="my-0 mx-0 m-0" href="<?=$this->QUICKBROWSE->DOMAIN;?>/youtube/video/<?=$uploadId;?>">
						<div class="jumbotron my-3 embed-responsive embed-responsive-16by9 bg-light" style="background-image: url('<?=$videodata['thumbnail_url'];?>') !important; background-size: cover !important; background-position: center !important; ">
							<div class="jumbotron width-10 height-10 bg-sharp-gradient-dark transparent-25" style="position: absolute; top: 0; left: 0; padding: 5px;"></div>
						</div>
					  </a>
					  <p class="text-center text-uppercase text-truncate font-weight-bold mb-2 text-<?=$txt_color;?>"><?=$videodata['title'];?></p>
					</div>
					<?php
				}
			}
		}catch(Exception $e){
			$this->ERROR = $e->getMessage();
			return false;
		}
		return true;
	}
	
	function html_upload($handler, $vid, $txt_color = 'dark'){
		try{
			$YOUTUBE = $handler;
			$videodata = $YOUTUBE->get_raw_data('video', $vid);
			$videodata['youtube'] = $YOUTUBE->get_raw_data('youtube', $vid);
			if(!$videodata){
				$this->ERROR = $YOUTUBE->ERROR;
				return false;
			}
			?>
			<h3 class="text-truncate py-3 text-<?=$txt_color;?>"><?=$videodata['title'];?></h3>
			<div class="embed-responsive embed-responsive-16by9 text-center">
				<iframe class="embed-responsive-item" src="https://www.youtube.com/embed/<?=$vid;?>?autoplay=1&controls=0&enablejsapi=1&fs=0&modestbranding=1&start=0&iv_load_policy=3" frameborder="0" allowfullscreen></iframe>
			</div>
			<div class="row">
				<div class="col-8">
					<h4 class="mt-3 text-left text-<?=$txt_color;?>">
						Author: <a class="text-secondary" href="<?=$videodata['author_url'];?>"><?=$videodata['author_name'];?></a>
					</h4>
				</div>
				<div class="col-4">
					<h4 class="mt-3 text-right text-<?=$txt_color;?>">
						Views: <span class="text-secondary"><?=$videodata['youtube']['items'][0]['statistics']['viewCount'];?></span>
					</h4>
				</div>
			</div>
			<?php
		}catch(Exception $e){
			$this->ERROR = $e->getMessage();
			return false;
		}
		return $true;
	}

	function html_alert_danger($message = ''){
		if(!empty($message)){
			?>
			<div class="alert alert-dismissible alert-danger">
			  <button type="button" class="close" data-dismiss="alert">&times;</button>
			  <strong>Error: </strong><?=$message;?>
			</div>
			<?php
		}
	}

	function html_alert_success($message = ''){
		if(!empty($message)){
			?>
			<div class="alert alert-dismissible alert-success">
			  <button type="button" class="close" data-dismiss="alert">&times;</button>
			  <strong>Success: </strong><?=$message;?>
			</div>
			<?php
		}
	}

	function html_header($title = 'title', $description = 'description', $css_classes = 'bg-gradient-purple text-light text-center'){
		?>
		<header class="<?=$css_classes;?>">
			<div class="container">
				<h1 class="display-2 text-truncate text-light"><?=$title;?></h1>
				<p class="lead text-light"><?=$description;?></p>
			</div>
		</header>
		<?php
	}

	function html_pagination($CURRENT_INDEX = 0, $HARD_INDEX_LIMIT = 10, $ITEMS_PER_PAGE = 3, $TOTAL_ITEMS, $START_URL = './group/', $URL_INDEX = './group/page/'){
		?>
		<nav id="nav-pagination">
		  <ul class="pagination" style="justify-content: center;">
			<li class="page-item <?php if($CURRENT_INDEX + 1 <= 1){ echo 'disabled'; }?>">
			  <a class="page-link" href="<?=$START_URL;?>">First</a>
			</li>
			<li class="page-item <?php if($CURRENT_INDEX + 1 <= 1){ echo 'disabled'; }?>">
			  <a class="page-link" href="<?php if($CURRENT_INDEX <= 1){ echo $START_URL; }else{ echo $URL_INDEX . ($CURRENT_INDEX - 1); };?>"><i class="fas fa-chevron-left"></i></a>
			</li>
			<?php
			//set index limit based on how many posts there are
			$INDEX_LIMIT = ceil($TOTAL_ITEMS / $ITEMS_PER_PAGE);

			//check if there are not to many pages, hard limit from old $INDEX_LIMIT = 10?
			if($INDEX_LIMIT > $HARD_INDEX_LIMIT){
				$INDEX_LIMIT = $HARD_INDEX_LIMIT;
			}

			//Add amount of pages to the pagination bar
			for($i = 0; $i < $INDEX_LIMIT; $i++){
				$active = false;
				if($i == $CURRENT_INDEX){
					$active = true;
				}
				?>
				<li class="page-item <?php if($active){ echo 'active'; } ?>">
					<?php
					if($i <= 0){
						?><a class="page-link" href="<?=$START_URL;?>"><?=$i+1;?></a><?php
					}else{
						?><a class="page-link" href="<?=$URL_INDEX . $i;?>"><?=$i+1;?></a><?php
					}
					?>
				</li>
				<?php
			}
			?>
			<li class="page-item <?php if($CURRENT_INDEX + 1 >= $INDEX_LIMIT || $INDEX_LIMIT <= 1){ echo 'disabled'; }?>">
			  <a class="page-link" href="<?=$URL_INDEX . ($CURRENT_INDEX + 1);?>"><i class="fas fa-chevron-right"></i></a>
			</li>
			<li class="page-item <?php if($CURRENT_INDEX + 1 >= $INDEX_LIMIT){ echo 'disabled'; }?>">
			  <a class="page-link" href="<?=$URL_INDEX . ($INDEX_LIMIT - 1);?>">Last</a>
			</li>
		  </ul>
		</nav>
		<?php

	}

	function html_code_from_file($file, $showlines = true){
		?><pre class="bg-dark text-light"><?php
		$txt_lines = explode("\n", file_get_contents($file));
		$cnt_lines = 0;
		foreach($txt_lines as $line){
			$cnt_lines++;
			$data_line = '' . $cnt_lines . '';
			if(strlen($data_line) <= 1){
				$data_line = '0' . $data_line;
			}
			$line = $this->convert_code($line);
			?><span data-line-number="<?=$data_line;?>" class="line"><?=$line;?></span><?php
		}
		?></pre><?php
	}

}

?>