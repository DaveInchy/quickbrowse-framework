<?php

	//BUGFIX: HEADERS NOT WORKING FOR SOME SERVERS
	ob_start();
	
	//ALWAYS INITIALIZE SESSIONS.
	session_start();
	
	//REQUIRE QUICKBROWSE AND ITS COMPONENTS
	require_once(__DIR__ . '/settings.php');
	require_once(__DIR__ . '/php/assetspack.class.php');
	require_once(__DIR__ . '/php/page.class.php');
	require_once(__DIR__ . '/php/database.class.php');
	require_once(__DIR__ . '/php/crud.class.php');
	require_once(__DIR__ . '/php/quickbrowse.class.php');
	
	//INITIALIZE QUICKBROWSE
	$QB = new QuickBrowse(false);
	
	//CHECK FOR QUICKBROWSE ERRORS
	if(!$QB){
		die($QB->ERROR);
	}
	
	//STOP HEADER BUGFIX;
	ob_end_flush();

?>
