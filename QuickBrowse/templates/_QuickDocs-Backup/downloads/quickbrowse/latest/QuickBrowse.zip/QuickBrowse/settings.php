<?php

class QuickBrowseSettings{
	
	//QuickBrowse Settings. (change only if you know what you're doing)
	public $VERSION			= 'release-3.4.2';
	public $DEBUG			= 'off';
	public $DOCS_URL		= 'https://quickbrow.se/docs/';
	
	//API Settings.
	public $API_DOMAIN		= 'api.quickbrow.se';
	public $API_VERSION		= 'v1';
	public $API_KEY			= '#demo-api-key';
	
	//Website Settings.
	public $DOMAIN			= 'https://quickbrow.se';
	public $TEMPLATE_NAME	= 'QuickDocs';
	
	//Main Database Settings.
	public $DB_SERVER 		= 'localhost';
	public $DB_NAME 		= 'database';
	public $DB_USER			= 'root';
	public $DB_PASSWORD		= '';
	
	//AssetPack Settings.
	public $LOAD_ASSETS		= true;
	public $USE_CDN			= false;

}
	
?>