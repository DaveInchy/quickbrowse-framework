<?php

class Database{
	
	public $ERROR = "";
	public $INFO = "";
	
	private $DB_SERVER;
	private $DB_USER;
	private $DB_PASSWORD;
	private $DB_NAME;
	
	private $CONN;

	function __construct($db_user = '', $db_pass = '', $db_server = '', $db_name = ''){
		
		try{
			if(isset($db_user) && !empty($db_user)
			&& isset($db_pass) && !empty($db_pass)
			&& isset($db_server) && !empty($db_server)
			&& isset($db_name) && !empty($db_name)
			){
				$this->INFO = $this->INFO . "\n Setting Database information.";
				$this->DB_USER = $db_user;
				$this->DB_PASSWORD = $db_pass;
				$this->DB_SERVER = $db_server;
				$this->DB_NAME = $db_name;
			}else{
				$this->ERROR = $this->ERROR . "\n You need to give all four arguments in new Database(user, password, server, database)";
				return false;
			}
			$this->INFO = $this->INFO . "\n Saving Mysqli connection to this Object.";
			$this->CONN = $this->connect();
			if(!$this->CONN){
				$this->ERROR = $this->ERROR . "\n Connection could not be saved, abort.";
				return false;
			}
		}catch(Exception $e){
			$this->ERROR = $this->ERROR . '\n Constructor failed with error: ' . $e->getMessage() . '.';
			return false;
		}
		return true;
	}
	
	function connect(){
		
		$MYSQLI = new mysqli($this->DB_SERVER, $this->DB_USER, $this->DB_PASSWORD, $this->DB_NAME);
		if($MYSQLI->connect_errno){
			$this->INFO = $this->INFO . '\n Make sure the database settings are correct.';
		    $this->ERROR = $this->ERROR . "\n Connection failed (" . $MYSQLI->connect_error . ')';
			return false;
		}
		$this->INFO = "Connected to Database";
		return $MYSQLI;
	}
	
	function data_fetch($TABLE, $ARGS){
		
		$CONNECTION = $this->CONN;
		
		if(isset($TABLE)){
			if(isset($ARGS) && isset($ARGS['TYPE'])){
				switch($ARGS['TYPE']){
					
					case 'DATA_RANDOM':
						$this->INFO = $this->INFO . '\n Selecting all rows from ' . $TABLE . ' ordered by RAND().';
						$QUERY = 'SELECT * FROM ' . $TABLE . ' ORDER BY RAND()';
					break;
					
					case 'DATA_RANDOM_LIMIT':
						if(!isset($ARGS['LIMIT']) || empty($ARGS['LIMIT'])){
							$this->ERROR = $this->ERROR . '\n Could not select ' . $ARGS['LIMIT'] . ' rows from ' . $TABLE . '.';
							return false;
						}
						$this->INFO = $this->INFO . '\n Selecting ' . $ARGS['LIMIT'] . ' rows from ' . $TABLE . ' ordered by RAND().';
						$QUERY = 'SELECT * FROM ' . $TABLE . ' ORDER BY RAND() LIMIT ' . $ARGS['LIMIT'] . '';
					break;
					
					case 'DATA_NEWEST':
						$this->INFO = $this->INFO . '\n Selecting all newest rows from ' . $TABLE . '.';
						$QUERY = 'SELECT * FROM ' . $TABLE . ' ORDER BY id DESC';
					break;
					
					case 'DATA_OLDEST':
						$this->INFO = $this->INFO . '\n Selecting all oldest rows from ' . $TABLE . '.';
						$QUERY = 'SELECT * FROM ' . $TABLE . ' ORDER BY id ASC';
					break;
					
					case 'DATA_NEWEST_LIMIT':
						if(!isset($ARGS['LIMIT']) || empty($ARGS['LIMIT'])){
							$this->ERROR = $this->ERROR . '\n Could not select ' . $ARGS['LIMIT'] . ' newest rows from ' . $TABLE . '.';
							return false;
						}
						$this->INFO = $this->INFO . '\n Selecting ' . $ARGS['LIMIT'] . ' newest rows from ' . $TABLE . '.';
						$QUERY = 'SELECT * FROM ' . $TABLE . ' ORDER BY id DESC LIMIT ' . $ARGS['LIMIT'] . '';
					break;
					
					case 'DATA_OLDEST_LIMIT':
						if(!isset($ARGS['LIMIT']) || empty($ARGS['LIMIT'])){
							$this->ERROR = $this->ERROR . '\n Could not select ' . $ARGS['LIMIT'] . ' oldest rows from ' . $TABLE . '.';
							return false;
						}
						$this->INFO = $this->INFO . '\n Selecting ' . $ARGS['LIMIT'] . ' oldest rows from ' . $TABLE . '.';
						$QUERY = 'SELECT * FROM ' . $TABLE . ' ORDER BY id ASC LIMIT ' . $ARGS['LIMIT'] . '';
					break;
					
					case 'DATA_NEWEST_OFFSET':
						if(!isset($ARGS['LIMIT']) || empty($ARGS['LIMIT']) || !isset($ARGS['OFFSET']) || empty($ARGS['OFFSET'])){
							$this->ERROR = $this->ERROR . '\n Could not select newest offset rows (' . $ARGS['OFFSET'] . ' to ' . $ARGS['LIMIT'] . ') from ' . $TABLE . '.';
							return false;
						}
						$this->INFO = $this->INFO . '\n Selecting newest offset rows (' . $ARGS['OFFSET'] . ' to ' . $ARGS['LIMIT'] . ') from ' . $TABLE . '.';
						$QUERY = 'SELECT * FROM ' . $TABLE . ' ORDER BY id DESC LIMIT ' . $ARGS['LIMIT'] . ' OFFSET ' . $ARGS['OFFSET'] . '';
					break;
					
					case 'DATA_OLDEST_OFFSET':
						if(!isset($ARGS['LIMIT']) || empty($ARGS['LIMIT']) || !isset($ARGS['OFFSET']) || empty($ARGS['OFFSET'])){
							$this->ERROR = $this->ERROR . '\n Could not select oldest offset rows (' . $ARGS['OFFSET'] . ' to ' . $ARGS['LIMIT'] . ') from ' . $TABLE . '.';
							return false;
						}
						$this->INFO = $this->INFO . '\n Selecting oldest offset rows (' . $ARGS['OFFSET'] . ' to ' . $ARGS['LIMIT'] . ') from ' . $TABLE . '.';
						$QUERY = 'SELECT * FROM ' . $TABLE . ' ORDER BY id ASC LIMIT ' . $ARGS['LIMIT'] . ' OFFSET ' . $ARGS['OFFSET'] . '';
					break;
					
					default:
						$this->ERROR = $this->ERROR . '\n Theres no type argument (ARGS["TYPE"]) called: ' . $ARGS['TYPE'] . '.\n Make sure you are using capital letters.';
						return false;
					break;
					
				}
			}else{
				$this->ERROR = $this->ERROR . "\n Second argurment invalid in data_fetch(TABLE = 'posts', ARGS = Array('TYPE' => 'DATA_NEWEST', 'LIMIT' => '0', 'OFFSET' => '0')).
				\n Make sure to use: " . '$ARGS["TYPE"] = "DATA_RANDOM"; for example.' . "\n Make sure you create an array with arguments like: " . '$ARGS["TYPE/LIMIT/OFFSET"] = value' . ".";
				$this->INFO = $this->INFO . '\n Selecting all rows from table: ' . $TABLE . ' newest first.';
				$QUERY = 'SELECT * FROM ' . $TABLE . ' ORDER BY id DESC';
			}
			
			try{
				$this->INFO = $this->INFO . '\n Started query (' . $QUERY . ').';
				$RESULT = $CONNECTION->query($QUERY);
				if(!$RESULT){
					$this->INFO = $this->INFO . '\n This is not your fault, Contact us so we can repair this build.';
					$this->ERROR = $this->ERROR . '\n Failed doing query: ('. $QUERY . ") --> MYSQL ERROR: " . mysqli_error($CONNECTION) . "";
					return false;
				}else{
					while($DATA = $RESULT->fetch_array()){
						$ARRAY[] = $DATA;
					}
					$this->INFO = '\n Finished query: (' . $QUERY . ').';
					
					if(!isset($ARRAY) || empty($ARRAY)){
						$this->ERROR = $this->ERROR . '\n Result is empty, something still went wrong...';
						return false;
					}
					return $ARRAY;
				}
			}catch(Exception $e){
				$this->ERROR = $this->ERROR . '\n Caught exception: ' . $e->getMessage() . '.';
				return false;
			}
		}else{
			$this->ERROR = $this->ERROR . "\n Missing first argument TABLE in data_fetch(TABLE = 'posts', ARGS = Array('TYPE' => 'DATA_NEWEST', 'LIMIT' => '0', 'OFFSET' => '0')).";
			return false;
		}
		return false;
	}
	
	function data_create($CRUD, $TABLE){
		
		if(!isset($CRUD) || empty($CRUD)){
			$this->ERROR = $this->ERROR . "\n CRUD Object must be given to get latest row from.";
			return false;
		}
		
		$CONNECTION = $this->CONN;
		$QUERY = "INSERT INTO " . $TABLE . " () VALUES()";
		if(!$CONNECTION->query($QUERY)){
			$this->ERROR = $this->ERROR . '\n Failed to query creation into: ' . $TABLE . '.\n ' . $CONNECTION->error . '.';
			return false;
		}
		
		$ARGS['TYPE'] = 'DATA_OLDEST';
		$DATA = $CRUD->data_read($TABLE, $ARGS);
		foreach($DATA as $ROW){
			$RID = $ROW['id'];
		}
		return $RID;
	}
	
	function data_insert($ARRAY, $ID, $TABLE){
		
		$CONNECTION = $this->CONN;
		
		$KEYS = array_keys($ARRAY);
		foreach($KEYS as $KEY){
			
			$COLUMN = $KEY;
			$INPUT = $ARRAY[$KEY];
			
			$QUERY = 'UPDATE ' . $TABLE . ' SET ' . $COLUMN . ' = "' . mysqli_real_escape_string($CONNECTION, $input) . '" WHERE id = "' . $ID . '"; ';
			if(!$CONNECTION->query($QUERY)){
			    $this->ERROR = $this->ERROR . '\n Failed to query update for: ' . $ID . '.\n ' . $CONNECTION->error . '.';
				return false;
			}
			$this->INFO = $this->INFO . '\n Successfully updated ' . $COLUMN . ' for: ' . $ID . '.';
		}
		return true;
	}
	
	function data_delete($ID, $TABLE){
		
		$CONNECTION = $this->CONN;
		
		$QUERY = 'DELETE FROM ' . $TABLE . ' WHERE id = ' . $ID;
		if(!$CONNECTION->query($QUERY)) {
		    $this->ERROR = $this->ERROR . '\n Failed to query delete for: ' . $ID . '.\n ' . $CONNECTION->error . '.';
			return false;
		}
		$this->INFO = $this->INFO . "\n Successfully deleted id: " . $ID . " from table: " . $TABLE . ".";
		return true;
	}

}
	
?>