<?php

//------------------------\\//------------------------------------------------\\//------------------------------------------------\\//------------------------\\
// Author: 		DoOnline
// Contact: 	contact@doonline.nl
// Version: 	3.2
// Class: 		Page() (page.class.php)
// Required: 	None
// Location:	QuickBrowse PHP Class
//
// Functions: Handling Views and which content is shown.
//  - _construct();						-> Constructing the Page() Object.
//
//	- get_page()						-> Returns the current page file based on URL.
//
//  - get_page_name()					-> Returns the current page name based on URL
//
//------------------------\\//------------------------------------------------\\//------------------------------------------------\\//------------------------\\

class Page{
	
	public $ERROR = '';
	public $INFO = '';
	
	private $PAGE;
	private $CONTENTID = '';
	private $SUBDIR = Array();
	private $LINKED = Array(
		'home' => 'index.php'
	);
	
	//Set page on load.
	function __construct(){
		
		if($this->set_page()){
			return false;
		}
		return true;
		
	}
	
	//Go to url
	function redirect($url){
		global $QUICKBROWSE;
		if(!isset($url) || empty($url)){
			$this->ERROR = $this->ERROR . '\nURL parameter not set in function go(string $url).';
			return false;
		}
		header('Location: ' . $QUICKBROWSE->DOMAIN . $url);
		exit();
	}
	
	//If you've set more links, overwrite the current set page.
	function set_page(){
		global $QUICKBROWSE;
		//Deconstructing URL and selecting which page should be displayed.
		$url = $_SERVER["REQUEST_URI"];
		//If theres more then $def slashes un url. Moved directory up -> modify $FRONTEND_ROOT
		$defs = 1;
		$dirs = substr_count($url, '/');
		if($dirs > $defs){
			//Modify template frontend root setting
			$first = true;
			for($defs; $defs < $dirs; $defs++){
				//Save subdirs
				if($first){
					$this->SUBDIR[$defs] = strtok($url, '/');
					$first = false;
				}else{
					$this->SUBDIR[$defs] = strtok('/');
				}
			}
		}
		$page = strtok( basename($url) , '?');
		//Set page as page.php by default.
		if(isset($page) && !empty($page)){
			$this->PAGE = $page . '.php';
			//Check if page has a linked file.
			if(isset($this->LINKED[$page]) && !empty($this->LINKED[$page])){
				//Set the page to the linked file.
				$this->PAGE = $this->LINKED[$page];
			}
		}else{
			$this->PAGE = 'index.php';
		}
		return true;
		
	}
	
	function get_subdir_list(){
		return $this->SUBDIR;
	}
	
	function get_subdir_data(){
		$offset = Array();
		$path = Array();
		$subdirs = $this->get_subdir_list();
		if(isset($subdirs) && !empty($subdirs)){
			foreach($subdirs as $subdir){
				$count = 0;
				$path[$count] = '';
				$offset[$count] = $subdir;
				foreach($offset as $dir){
					$offset[$count + 1] = $dir;
					$path[$count + 1] = $dir . '/' . $path[$count];
					$count++;
				}
				$offset[0] = $this->get_page_name();
			}
			
			//Format the data
			$DATA = Array(
				'dir' => $offset,
				'path' => $path,
				'length' => $count
			);
			
		}else{
			//Format empty data
			$DATA = Array(
				'dir' => Array(),
				'path' => Array(),
				'length' => '0'
			);
			
		}
		return $DATA;
	}
	
	function get_page_name(){
		return str_replace('.php', '', $this->PAGE);
	}
	
	function get_page_file(){
		return $this->PAGE;
	}
	
	function set_content_id($value){
		$this->CONTENTID = $value;
		return true;
	}
	
	function get_content_id(){
		return $this->CONTENTID;
	}
	
	function set_link($page, $file){
		$this->INFO = "Checking if link already exists.";
		if(!isset($this->LINKED[$page]) || empty($this->LINKED[$page])){
			$this->INFO = $this->INFO . "\n Linked page (" . $page . ") to file (" . $file . ").";
			$this->LINKED[$page] = $file;
		}else{
			$this->ERROR = $page . " is already linked to " . $LINKED[$page] . "";
			return false;
		}
		return true;
	}
	
}
	
?>
