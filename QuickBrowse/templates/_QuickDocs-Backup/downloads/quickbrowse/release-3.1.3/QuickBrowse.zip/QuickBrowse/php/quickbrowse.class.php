<?php

class QuickBrowse extends QuickBrowseSettings{
	
	public $ERROR = '';
	public $INFO = '';
	public $ROOT = './QuickBrowse';
	public $TEMPLATE_ROOT;
	public $FRONTEND_ROOT;
	public $ASSETSPACK;
	
	function __construct(){
		//1.0 SET PHP ERROR REPORTING
		$this->INFO = $this->INFO . "\n Setting php error reporting to " . $this->DEBUG . ".";
		if(!$this->set_php_errors(true)){
			$this->ERROR = $this->ERROR . "\n Something went wrong trying to set error reporting to " . $this->DEBUG . ".";
		}
		
		//2.0 SETTING MORE DYNAMIC SETTINGS
		$this->INFO = $this->INFO . "\n Loading dynamic settings.";
		if(!$this->set_dynamic_settings()){
			$this->ERROR = $this->ERROR . "\n Couldn't set dynamic settings.";
		}
		
		//3.0 CHECKING QUICKBROWSE FILE STRUCTURES
		$this->INFO = $this->INFO . "\n Loading QuickBrowse and checking program structure.";
		if(!$this->check_quickbrowse_structure()){
			$this->ERROR = $this->ERROR . "\n Couldn't load QuickBrowse.";
		}
		
		//3.1 CHECKING TEMPLATE FILE STRUCTURES
		$this->INFO = $this->INFO . "\n Loading template (" . $this->TEMPLATE_NAME . ") and checking program structure.";
		if(!$this->check_template_structure()){
			$this->ERROR = $this->ERROR . "\n Couldn't load template (" . $this->TEMPLATE_NAME . ").";
		}
	}
	
	private function check_quickbrowse_structure(){
		$dir = "/php/";
		$files = Array(
			"database.class.php",
			"data.class.php",
			"page.class.php"
		);
		foreach($files as $file){
			if(!file_exists($this->ROOT . $dir . $file)){
				$this->ERROR = $this->ERROR . "\n Couldn't find class (" . $file . ") in directory (" . $this->ROOT . $dir . ").";
				return false;
			}
		}
		return true;
	}
	
	private function check_template_structure(){
		$files = Array(
			"template.php",
			"header.php",
			"settings.php"
		);
		foreach($files as $file){
			if(!file_exists($this->TEMPLATE_ROOT . '/' . $file)){
				$this->ERROR = $this->ERROR . "\n Couldn't find " . $file . " in directory (" . $this->TEMPLATE_ROOT . ").";
				return false;
			}
		}
		return true;
	}
	
	private function set_php_errors($NOTICE = false){
		try{
			if(!$NOTICE){
				$errors = E_ALL;
			}else{
				$errors = E_ALL & ~E_NOTICE;
			}
			ini_set('error_reporting', $errors);
			ini_set('display_errors', $this->DEBUG);
		}catch(Exception $e){
			$this->ERROR = $this->ERROR . "\n Caught Exception: " . $e->getMessage() . '.';
			return false;
		}
		return true;
	}
	
	private function set_dynamic_settings(){
		try{
			$QUICKBROWSE_DIR = str_replace('./', '', $this->ROOT);
			$ASSETS_URL = $this->DOMAIN . '/' . $QUICKBROWSE_DIR . '/assets/';
			$ASSETS_DIR = $this->ROOT . '/assets/';
			
			$this->TEMPLATE_ROOT	= $this->ROOT . '/templates/' . $this->TEMPLATE_NAME;
			$this->FRONTEND_ROOT	= $this->DOMAIN . '/' . $this->TEMPLATE_ROOT;
			
			$this->ASSETSPACK = new AssetsPack($ASSETS_URL, $ASSETS_DIR, $this->USE_CDN);
			if(!empty($this->ASSETSPACK->ERROR)){
				$this->ERROR = $this->ERROR . "\n " . $this->ASSETSPACK->ERROR;
				return false;
			}
		}catch(Exception $e){
			$this->ERROR = $this->ERROR . "\n Caught Exception: " . $e->getMessage() . '.';
			return false;
		}
		return true;
	}
	
}

?>