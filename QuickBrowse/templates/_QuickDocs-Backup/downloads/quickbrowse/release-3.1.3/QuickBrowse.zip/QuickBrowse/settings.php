<?php

//TIP: You can call these values with for example: $QUICKBROWSE->VERSION.
//TIP: Look on https://quickbrow.se for the documentation and how to configure these settings.

class QuickBrowseSettings{
	
	//QuickBrowse Settings. (change only if you know what you're doing)
	public $VERSION			= 'release-3.1.3';
	public $DEBUG			= 'off';
	public $DOCS_URL		= 'https://quickbrow.se/docs/';
	
	//Website Settings.
	public $DOMAIN			= 'https://quickbrow.se';
	public $TEMPLATE_NAME	= 'QuickDocs';
	
	//Database Settings.
	public $DB_SERVER 		= 'localhost';
	public $DB_NAME 		= 'database';
	public $DB_USER			= 'root';
	public $DB_PASSWORD		= '';
	
	//AssetPack Settings.
	public $USE_CDN			= true;

}
	
?>