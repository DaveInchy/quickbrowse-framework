<?php

class Data{
	
	public $DEBUG = false;
	public $ERROR = '';
	public $INFO = '';
	
	private $DATABASE;
	
	function __construct($database){
		try{
			$this->INFO = $this->INFO = "Setting database Object to this->DATABASE.\n";
			$this->DATABASE = $database;
		}catch(Exception $e){
			$this->ERROR = $this->ERROR . "Caught Exception: " . $e->getMessage() . ".\n";
		}
	}
	
	function data_create($ARRAY, $TABLE){
		
		$DATABASE = $this->DATABASE;
		
		$id = $DATABASE->data_create($this, $TABLE);
		if(!$id){
			$this->ERROR = 'Failed to execute $DATABASE->data_create() function and get $id.';
			return false;
		}
		
		if(!$DATABASE->data_insert($ARRAY, $id, $TABLE)){
			$this->ERROR = 'Failed to execute $this->data_create() function.';
			$this->ERROR = $this->ERROR . "<br>" . $DATABASE->ERROR;
			return false;
		}
		return $id;

	}
	
	function data_read($TABLE, $ARGS){
		
		$DATABASE = $this->DATABASE;
		
		if(!isset($ARGS)){
			$ARGS['TYPE'] = 'DATA_NEWEST';
		}	
		
		$data = $DATABASE->data_fetch($TABLE, $ARGS);
		if(!$data){
			$this->ERROR = $DATABASE->ERROR;
		}else{
			return $data;
		}
		return false;
		
	}
	
	function data_update($ARRAY, $TABLE, $ID){
		
		$DATABASE = $this->DATABASE;
		
		if(!$DATABASE->data_insert($ARRAY, $ID, $TABLE)){
			$this->ERROR = 'Failed to execute data_update() function.';
			$this->ERROR = $this->ERROR . "<br>" . $DATABASE->ERROR;
			return false;
		}
		return true;
		
	}
	
	function data_delete($TABLE, $ID){
		
		$DATABASE = $this->DATABASE;
		
		if(!$DATABASE->data_delete($ID, $TABLE)){
			$this->ERROR = 'Failed to execute data_delete() function.';
			return false;
		}
		return true;
		
	}
	
}
	
?>