<?php

class AssetsPack{
	
	public $ERROR = '';
	public $INFO = '';
	public $ROOT;
	public $ROOT_URL;
	public $DISPLAY;
	
	private $CDN_URL = 'https://quickbrow.se/QuickBrowse/assets/';
	private $ASSET;
	private $ASSET_LIST = Array
	(
		'css/' => Array
		(
			'responsive.css',
			'utility.css'
		),
		'css/lib/animate/' => Array
		(
			'animate.css'
		),
		'css/lib/bootstrap/' => Array
		(
			'bootstrap.min.css',
			'bootstrap-navbar.css'
		),
		'bootswatch/' => Array
		(
			'bootstrap.css',
			'cerulean.css',
			'cosmo.css',
			'cyborg.css',
			'darkly.css',
			'flatly.css',
			'journal.css',
			'litera.css',
			'lumen.css',
			'lux.css',
			'materia.css',
			'minty.css',
			'pulse.css',
			'sandstone.css',
			'simplex.css',
			'sketchy.css',
			'slate.css',
			'spacelab.css',
			'superhero.css',
			'united.css',
			'yeti.css',
		),
		'js/lib/wowjs/' => Array
		(
			'wow.min.js'
		),
		'js/lib/jquery/' => Array
		(
			'jquery.min.js',
			'jquery-slim.min.js',
			'jquery-easing.min.js'
		),
		'js/lib/bootstrap/' => Array
		(
			'bootstrap.js',
			'bootstrap-navbar.js'
		),
		'img/pattern/' => Array
		(
			'chalkboard.jpg',
			'figures.png',
			'paper.jpg'
		),
		'img/background/' => Array
		(
			'space.svg'
		),
		'img/icon/' => Array
		(
			'favicon.ico',
			'favicon-16.png',
			'favicon-32.png',
			'favicon-96.png',
			'favicon-192.png'
		),
		'img/logo/' => Array
		(
			'logo.png',
			
			'logo-doonline-sm.png',
			'logo-webbouwerz-sm.png',
			'logo-bootstrap-sm.png',
			'logo-bootswatch-sm.png',
			
			'logo-bootswatch-lg.png',
			'logo-bootstrap-lg.png',
			'logo-doonline-lg.jpg',
		)
	);
	
	function __construct($ROOT_URL, $ROOT_DIR, $CDN = false){
		try{
			//LOADING ASSETS INTO $QUICKBROWSE->ASSETSPACK->ASSET
			$this->INFO 	= $this->INFO . "\n Constructing and Loading assetspack";
			$this->ROOT_URL = $ROOT_URL;
			$this->ROOT 	= $ROOT_DIR;
			
			if(!$this->load_assets($CDN)){
				$this->ERROR = $this->ERROR . "\n Something went wrong while Loading assets.";
				return false;
			}
			
			$this->INFO = $this->INFO . "\n Adding Display functionality.";
			$this->DISPLAY = new AssetsPackHTML();
			
		}catch(Exception $e){
			$this->ERROR = $this->ERROR . "\n Constuctor for assetspack failed: " . $e->getMessage() . ".";
			return false;
		}
		$this->INFO = $this->INFO . "\n Finished Constructing and Loading assetsoack";
		return true;
	}
	
	private function load_assets($cdn){
		try{
			$this->INFO = $this->INFO . '\n Searching trough assets list for files.';
			foreach($this->ASSET_LIST as $loc => $files){
				foreach($files as $file){
					if(!$this->set_asset($cdn, $loc, $file)){
						$this->ERROR = $this->ERROR . "\n Couldn't set asset: " . $key . $file . '.';
						return false;
					}
				}
			}
		}catch(Exception $e){
			$this->ERROR = $this->ERROR . "\n Caught Exception: " . $e->getMessage() . '.';
			return false;
		}
		return true;
	}
	
	private function asset_exists($asset){
		$this->INFO = $this->INFO . "\n Checking if asset " . $asset . " exists.";
		if(!isset($this->ASSET[$asset])){
			$this->ERROR = $this->ERROR . "\n No asset found named: " . $asset . ".";
			return false;
		}
		return true;
	}
	
	private function set_asset($cdn, $location, $file){
		try{
			$this->INFO = $this->INFO . "\n Loading " . $location[0] . $file . " into assetspack.";
			
			//Format asset into call type. Example: IMG-LOGO, CSS-UTILITY, use print_assets() to get the whole list
			$asset = strstr($file, '.', true);
			$asset = strstr($location, '/', true) . '-' . $asset;
			$asset = strtoupper($asset);
			
			$cdn_url = $this->CDN_URL . $location . $file;
			$url = $this->ROOT_URL . $location . $file;
			$filepath = $this->ROOT . $location . $file;
			if($cdn == false){
				if(!file_exists($filepath)){
					$this->ERROR = $this->ERROR . "\n Couldn't find filepath: " . $filepath . ".";
					return false;
				}
				$this->ASSET[$asset] = $url;
				$this->INFO = $this->INFO . "\n Saved a valid file to: " . $url . " into assetspack.";
			}else{
				$this->ASSET[$asset] = $cdn_url;
				$this->INFO = $this->INFO . "\n Used cdn as valid file to: " . $url . " into assetspack.";
			}
		}catch(Exception $e){
			$this->ERROR = $this->ERROR . "\n Caught Exception: " . $e->getMessage() . '.';
			return false;
		}
		return true;
	}
	
	function get_asset($asset){
		$this->INFO = $this->INFO . "\n Trying to return asset " . $asset . ".";
		if(!$this->asset_exists($asset)){
			$this->ERROR = $this->ERROR . "\n Failed to return asset, asset " . $asset . " does not exist.";
			return false;
		}
		return $this->ASSET[$asset];
	}
	
	function print_assets(){
		?><pre class="bg-chalk text-light"><?php
		$c = 0;
		foreach($this->ASSET as $key => $file){
			$c++;
			$space = '		';
			if(strlen($c) <= 1){
				$c = '0' . $c;
			}
			if(strlen($key) <= 12){
				$space = '	' . $space;
			}
			if(strlen($key) > 20){
				$space = '	';
			}
			?><span class="line" data-line-number="<?=$c;?>">TYPE: <?=$key;?><?=$space;?><?=$file;?></span><br><?php
		}
		?></pre><?php
	}
	
	function img($asset = 'IMG-LOGO-DOONLINE', $size = '100%'){
		$this->INFO = $this->INFO . "\n Including image element with asset: " . $asset . ".";
		?><img width="<?=$size;?>" class="img-fluid" src="<?=$this->get_asset($asset);?>" alt="<?=$asset;?>"/><?php
	}
	
	function icon_pack(){
		$this->INFO = $this->INFO . "\n Including QuickBrowse favicons.";
		?>
			<!-- QuickBrowse Package - Icons -->
			<link rel="icon" type="image/png" sizes="192x192" href="<?=$this->get_asset('IMG-FAVICON-192');?>">
			<link rel="icon" type="image/png" sizes="96x96" href="<?=$this->get_asset('IMG-FAVICON-96');?>">
			<link rel="icon" type="image/png" sizes="32x32" href="<?=$this->get_asset('IMG-FAVICON-32');?>">
			<link rel="icon" type="image/png" sizes="16x16" href="<?=$this->get_asset('IMG-FAVICON-16');?>">
		<?php
	}
	
	function css_pack($bootstrap = false, $theme = 'none'){
		$this->INFO = $this->INFO . "\n Including QuickBrowse css.";
		if($bootstrap){
			$this->bootstrap('css', $theme);
		}
		?>
			<!-- QuickBrowse Style Package - QuickBrowse CSS -->
			<link type="text/css" href="<?=$this->get_asset('CSS-ANIMATE');?>" rel="stylesheet">
			<link type="text/css" href="<?=$this->get_asset('CSS-RESPONSIVE');?>" rel="stylesheet">
			<link type="text/css" href="<?=$this->get_asset('CSS-UTILITY');?>" rel="stylesheet">
		<?php
	}
	
	function js_pack($bootstrap = false){
		$this->INFO = $this->INFO . "\n Including QuickBrowse js.";
		if($bootstrap){
			$this->bootstrap('js');
		}
		?>
			<!-- QuickBrowse Javascript Package - QuickBrowse JS -->
			<script type="application/javascript" src="<?=$this->get_asset('JS-WOW');?>"></script>
		<?php
	}
	
	function meta_pack($title = 'Website build with ease because of https://QuickBrow.se', $description = 'Visit https://QuickBrow.se/get-started for more information.', $author = 'doOnline.nl', $theme_color = '#dc3545'){
		$this->INFO = $this->INFO . "\n Including QuickBrowse Head Metadata.";
		?>
			<!-- QuickBrowse Package - Metadata SEO -->
			<meta charset="utf-8">
			<title><?=$title;?></title>
			<meta name="description" content="<?=$description;?>">
			<meta name="author" content="<?=$author;?>">
			<!-- QuickBrowse Package - Web App Options -->
			<meta name="theme-color" content="<?=$theme_color;?>">
			<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<?php
	}
	
	function bootstrap($filetype = 'css', $theme = 'none'){
		$this->INFO = $this->INFO . "\n Including QuickBrowse Bootstrap " . $filetype . ".";
		switch(strtoupper($filetype)){
			case 'CSS':
				?>
					<!-- QuickBrowse Bootstrap Package - Main CSS -->
					<link type="text/css" href="<?=$this->get_asset('CSS-BOOTSTRAP');?>" rel="stylesheet">
					<!-- QuickBrowse Bootstrap Package - Navbar CSS -->
					<link type="text/css" href="<?=$this->get_asset('CSS-BOOTSTRAP-NAVBAR');?>" rel="stylesheet">
				<?php
				if($theme != 'none'){
				?>
					<!-- QuickBrowse Bootstrap Package - Bootswatch CSS -->
					<link type="text/css" href="<?=$this->get_asset(strtoupper($theme));?>" rel="stylesheet">
				<?php
				}
			break;
			
			case 'JS':
				?>
					<!-- QuickBrowse Bootstrap Package - JQuery JS -->
					<script type="application/javascript" src="<?=$this->get_asset('JS-JQUERY');?>"></script>
					<script type="application/javascript" src="<?=$this->get_asset('JS-JQUERY-EASING');?>"></script>
					<!-- QuickBrowse Bootstrap Package - Main JS -->
					<script type="application/javascript" src="<?=$this->get_asset('JS-BOOTSTRAP');?>"></script>
					<!-- QuickBrowse Bootstrap Package - Navbar JS -->
					<script type="application/javascript" src="<?=$this->get_asset('JS-BOOTSTRAP-NAVBAR');?>"></script>
				<?php
			break;
		}
	}
}

class AssetsPackHTML{
	
	public $ERROR = '';
	public $INFO = '';
	
	function html_alert_danger($error = ''){
		if(!empty($error)){
			?>
			<div class="alert alert-dismissible alert-danger">
			  <button type="button" class="close" data-dismiss="alert">&times;</button>
			  <strong>Error: </strong><?=$error;?>
			</div>
			<?php
		}
	}
	
	function html_alert_success($message = ''){
		if(!empty($message)){
			?>
			<div class="alert alert-dismissible alert-success">
			  <button type="button" class="close" data-dismiss="alert">&times;</button>
			  <strong>Success: </strong><?=$message;?>
			</div>
			<?php
		}
	}
	
	function html_header($title = 'title', $description = 'description', $css_classes = 'bg-gradient-blue text-light text-center'){
		?>
		<header class="<?=$css_classes;?>">
			<div class="container">
				<h1 class="display-2 text-truncate"><?=$title;?></h1>
				<p class="lead"><?=$description;?></p>
			</div>
		</header>
		<?php
	}
	
	function html_pagination($CURRENT_INDEX = 0, $HARD_INDEX_LIMIT = 10, $ITEMS_PER_PAGE = 3, $TOTAL_ITEMS, $START_URL = './group/', $URL_INDEX = './group/page/'){
		?>
		<nav id="nav-pagination">
		  <ul class="pagination" style="justify-content: center;">
			<li class="page-item <?php if($CURRENT_INDEX + 1 <= 1){ echo 'disabled'; }?>">
			  <a class="page-link" href="<?=$START_URL;?>">First</a>
			</li>
			<li class="page-item <?php if($CURRENT_INDEX + 1 <= 1){ echo 'disabled'; }?>">
			  <a class="page-link" href="<?php if($CURRENT_INDEX <= 1){ echo $START_URL; }else{ echo $URL_INDEX . ($CURRENT_INDEX - 1); };?>"><i class="fas fa-chevron-left"></i></a>
			</li>
			<?php
			//set index limit based on how many posts there are
			$INDEX_LIMIT = ceil($TOTAL_ITEMS / $ITEMS_PER_PAGE);

			//check if there are not to many pages, hard limit from old $INDEX_LIMIT = 10?
			if($INDEX_LIMIT > $HARD_INDEX_LIMIT){
				$INDEX_LIMIT = $HARD_INDEX_LIMIT;
			}
			
			//Add amount of pages to the pagination bar
			for($i = 0; $i < $INDEX_LIMIT; $i++){
				$active = false;
				if($i == $CURRENT_INDEX){
					$active = true;
				}
				?>
				<li class="page-item <?php if($active){ echo 'active'; } ?>">
					<?php
					if($i <= 0){
						?><a class="page-link" href="<?=$START_URL;?>"><?=$i+1;?></a><?php
					}else{
						?><a class="page-link" href="<?=$URL_INDEX . $i;?>"><?=$i+1;?></a><?php
					}
					?>
				</li>
				<?php
			}
			?>
			<li class="page-item <?php if($CURRENT_INDEX + 1 >= $INDEX_LIMIT || $INDEX_LIMIT <= 1){ echo 'disabled'; }?>">
			  <a class="page-link" href="<?=$URL_INDEX . ($CURRENT_INDEX + 1);?>"><i class="fas fa-chevron-right"></i></a>
			</li>
			<li class="page-item <?php if($CURRENT_INDEX + 1 >= $INDEX_LIMIT){ echo 'disabled'; }?>">
			  <a class="page-link" href="<?=$URL_INDEX . ($INDEX_LIMIT - 1);?>">Last</a>
			</li>
		  </ul>
		</nav>
		<?php
				
	}
	
	private function covert_code($text){
		$txt[1] = str_replace('&', '&amp', $text);
		$txt[2] = str_replace('<', '&lt', $txt[1]);
		$txt[3] = str_replace('>', '&gt', $txt[2]);
		$txt[4] = str_replace('$', '&#0036', $txt[3]);
		return $txt[4];
	}
	
	function html_code_from_file($file, $showlines = true){
		?><pre class="bg-dark text-light"><?php
		$txt_lines = explode("\n", file_get_contents($file));
		$cnt_lines = 0;
		foreach($txt_lines as $line){
			$cnt_lines++;
			$data_line = '' . $cnt_lines . '';
			if(strlen($data_line) <= 1){
				$data_line = '0' . $data_line;
			}
			$line = $this->convert_code($line);
			?><span data-line-number="<?=$data_line;?>" class="line"><?=$line;?></span><?php
		}
		?></pre><?php
	}
	
}

?>