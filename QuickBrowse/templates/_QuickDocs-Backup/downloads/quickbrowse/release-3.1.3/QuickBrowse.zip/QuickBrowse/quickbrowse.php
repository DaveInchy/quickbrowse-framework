<?php

	//BUGFIX: HEADERS NOT WORKING FOR SOME SERVERS
	ob_start();
	
	//ALWAYS INITIALIZE SESSIONS.
	session_start();
	
	//INITIALIZE QUICKBROWSE AND ITS COMPONENTS
	require_once(__DIR__ . '/settings.php');
	require_once(__DIR__ . '/php/quickbrowse.class.php');
	require_once(__DIR__ . '/php/assetspack.class.php');
	$QUICKBROWSE = new QuickBrowse();
	
	//INITIALIZE DATABASE CLASS
	require_once($QUICKBROWSE->ROOT . '/php/database.class.php');
	$DATABASE = new Database();
	
	//INITIALIZE DATA CLASS
	require_once($QUICKBROWSE->ROOT . '/php/data.class.php');
	$DATA = new Data($DATABASE);
	
	//INITIALIZE PAGE CLASS
	require_once($QUICKBROWSE->ROOT . '/php/page.class.php');
	$PAGE = new Page();
	
	//CHECK FOR QUICKBROWSE ERRORS
	if(!empty($QUICKBROWSE->ERROR) || !empty($DATABASE->ERROR) || !empty($PAGE->ERROR) || !empty($DATA->ERROR)){
		//FORMAT QUICKBROWSE ERRORS
		$ERRORS = Array(
			'$QUICKBROWSE' => Array(
				'ERROR' => $QUICKBROWSE->ERROR,
				'INFO' => $QUICKBROWSE->INFO
			),
			'$DATABASE' => Array(
				'ERROR: ' => $DATABASE->ERROR,
				'INFO: ' => $DATABASE->INFO
			),
			'$PAGE' => Array(
				'ERROR: ' => $PAGE->ERROR,
				'INFO: ' => $PAGE->INFO
			),
			'$DATA' => Array(
				'ERROR: ' => $DATA->ERROR,
				'INFO: ' => $DATA->INFO
			)
		);
		//PRINT QUICKBROWSE ERRORS
		?><pre style="width: 100%"><?php print_r($ERRORS); ?></pre><?php
	}else{
		//INITIALIZE TEMPLATE SETTINGS
		require_once($QUICKBROWSE->TEMPLATE_ROOT . '/settings.php');
		$TEMPLATE = new TemplateSettings();
		
		//CHECK TEMPLATE FOR REQUIRED CLASSES IF REQUIRE.PHP EXISTS.
		if(file_exists($QUICKBROWSE->TEMPLATE_ROOT . '/require.php')){
			//INITIALIZE TEMPLATE REQUIRED CLASSES
			include_once($QUICKBROWSE->TEMPLATE_ROOT . '/require.php');
		}
		
		//INITIALIZE TEMPLATE AND HEADER
		include_once($QUICKBROWSE->TEMPLATE_ROOT . '/header.php');
		include_once($QUICKBROWSE->TEMPLATE_ROOT . '/template.php');
	}
	
	//STOP HEADER BUGFIX;
	ob_end_flush();

?>
