<?php

class UserHandler{
	
	public $ERROR = '';
	public $INFO = '';
	
	public $DATA;
	
	function __construct($DATA_USERS){
		$this->DATA = $DATA_USERS;
		return true;
	}
	
	function get_session_data(){
		if($this->is_logged_in()){
			return $_SESSION['quickbrowse_user'];
		}
		return false;
	}
	
	function get_users_data(){
		$data = $this->DATA->data_read('users', Array('TYPE' => 'DATA_NEWEST'));
		return $data;
	}
	
	function get_user_data($id){
		$data = $this->DATA->data_read('users', Array('TYPE' => 'DATA_NEWEST'));
		foreach($data as $user){
			if($id == $user['id']){
				return $user;
			}
		}
		return false;
	}

	function register($FIRST_NAME, $LAST_NAME, $EMAIL, $PASSWORD){
		
	}

	function login($EMAIL, $PASSWORD){
		global $QUICKBROWSE;

		$users = $this->get_users_data();
		$found = false;
		foreach($users as $user){
			if($user['email'] == $EMAIL && $user['password'] == $PASSWORD){
				$_SESSION['quickbrowse_user_logged'] = true;
				$_SESSION['quickbrowse_user'] = $user;
				return true;
			}
		}
		$this->ERROR = 'Wrong credentials, make sure you have signed up at <a href="' . $QUICKBROWSE->DOMAIN . '/signup">Register</a>.';
		return false;
	}

	function logout(){
		if($this->is_logged_in()){
			$_SESSION['quickbrowse_user_logged'] = false;
			$_SESSION['quickbrowse_user'] = null;
			return true;
		}
		return false;
	}

	function is_logged_in(){
		if(isset($_SESSION['quickbrowse_user_logged'])){
			if($_SESSION['quickbrowse_user_logged'] == true){
				return true;
			}
		}
		return false;
	}
}
?>
