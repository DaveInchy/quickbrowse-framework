<?php
//--Initialize QuickBrowse PHP Modules that've been required in require.php--\\
$MAIL 				= new PHPMailer();

$GOOGLE_API_KEY		= 'Q34Be_qlz2kdf8yui03dfg';
$YOUTUBE 			= new YoutubeHandler($GOOGLE_API_KEY);

//--UserHandler Module example--\\
$CRUD				= $QB->CRUD;
$USER_TABLE			= 'users';
$LOGIN_URL			= $QB->DOMAIN . '/signin';
$REGISTER_URL		= $QB->DOMAIN . '/signup';
$DASHBOARD_URL		= $QB->DOMAIN . '/dashboard';
$UNIQUE				= '3X4MPL3;S7471C:UN1QU3-3NCRYP71ON2.S33D;IMPORTANT!NEVER_CHANGE_THIS_LATER';
$USER_HANDLE 		= new UserHandler($QB->CRUD, $TABLE, $REGISTER_URL, $LOGIN_URL, $DASHBOARD_URL, $UNIQUE);

//--Initialize Template PHP Modules that've been required in require.php--\\
$FUNCTIONS = new Functions();

//--Get sub-directory data and format example--\\
$URL_DATA 	= $QB->PAGE->get_subdir_data();
$URL_DIRS 	= $URL_DATA['dir'];
$URL_PAGE 	= $URL_DIRS[0];
$URL_DEPTH 	= $URL_DATA['length'];
$URL_PATH	= $URL_DATA['path'][$URL_DEPTH];

//--Register simple links without sub-directories example--\\
$QB->PAGE->set_link('signup', 'register.php');
$QB->PAGE->set_link('sign-up', 'register.php');
$QB->PAGE->set_link('signin', 'login.php');
$QB->PAGE->set_link('sign-in', 'login.php');
$QB->PAGE->set_link('log-in', 'login.php');
$QB->PAGE->set_link('404', 'error.php');

//--Reload registered page links, sets linked page in $QB->PAGE->get_page_file/name() after added links--\\
$QB->PAGE->set_page();

//--Load post data from database example--\\
//$POSTS = $QB->CRUD->data_read('posts', Array('TYPE' => 'DATA_NEWEST'));

//--Set THEME variable for later use example, using ASSETSPACK theme--\\
$THEME = "BOOTSWATCH-LUX";
?>