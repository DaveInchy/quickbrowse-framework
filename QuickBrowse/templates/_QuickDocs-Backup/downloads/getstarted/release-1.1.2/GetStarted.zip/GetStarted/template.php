<!DOCTYPE html>
<html lang="en">

	<head>

		<?=$QB->ASSETSPACK->meta_pack($QB->TEMPLATE->TITLE . ' by ' . $QB->TEMPLATE->AUTHOR . ' - ' . $QB->PAGE->get_page_name(), $QB->TEMPLATE->DESCRIPTION, $QB->TEMPLATE->AUTHOR);?>

		<?=$QB->ASSETSPACK->css_pack($THEME);?>
	  
	</head>
	<body>
	
		<?php
			//Include active page, if it doesn't exist load the error page.
			$headers 	= $QB->TEMPLATE_ROOT . '/headers/' . $QB->PAGE->get_page_file();
			$pages 		= $QB->TEMPLATE_ROOT . '/pages/' . $QB->PAGE->get_page_file();
			$error		= $QB->TEMPLATE_ROOT . '/pages/error.php';
			if(!file_exists($pages)){
				include_once($error);
			}else{
				if(file_exists($headers)){
					include_once($headers);
				}
				include_once($pages);
			}
		?>
		
		<?=$QB->ASSETSPACK->js_pack($QB->get_quickbrowsejs_data($USER_HANDLE));?>
	  
	</body>
</html>