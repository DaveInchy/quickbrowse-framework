<?php

class Functions{
	public $INFO = '';
	public $ERROR = '';
}

?>