<?php

class TemplateSettings{
	
	public $VERSION 		= '1.1.0';
	public $TITLE 			= 'Get Started';
	public $DESCRIPTION 	= 'A fully functional basic template for QuickBrowse';
	public $AUTHOR 			= 'Author';
	public $AUTHOR_URL		= 'https://author.com';
	public $AUTHOR_EMAIL	= 'contact@author.com';
}

?>