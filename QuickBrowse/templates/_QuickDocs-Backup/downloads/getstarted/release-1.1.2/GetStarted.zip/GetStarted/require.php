<?php

//REQUIRE QUICKBROWSE INCLUDED CLASSES
require_once($QB->ROOT . '/php/handler/mail/autoload.php');
require_once($QB->ROOT . '/php/handler/youtube.class.php');
require_once($QB->ROOT . '/php/handler/user.class.php');

//REQUIRE TEMPLATE CLASSES
require_once($QB->TEMPLATE_ROOT . '/php/functions.class.php');
	
?>